#!/usr/bin/env node

/**
 * TransferSwift File Organization Script
 * Helps organize and move files to GitHub repository
 */

const fs = require('fs');
const path = require('path');

class FileOrganizer {
    constructor() {
        this.workspacePath = '/workspace/transswift-global-banking';
        this.githubPath = '/workspace/github-upload';
        this.transferredFiles = [];
        this.issues = [];
    }

    createDirectoryStructure() {
        console.log('📁 Creating GitHub directory structure...');
        
        const structure = {
            'src/': ['models/', 'routes/', 'middleware/', 'utils/'],
            'public/': ['assets/js/', 'assets/css/', 'assets/images/'],
            'config/': ['database.js', 'app.js', 'security.js'],
            'docs/': ['API.md', 'DEPLOYMENT.md', 'ARCHITECTURE.md'],
            'tests/': ['unit/', 'integration/', 'e2e/'],
            'scripts/': ['deploy.sh', 'setup.sh', 'backup.sh'],
            'docker/': ['Dockerfile', 'docker-compose.yml', '.dockerignore'],
            'k8s/': ['deployment.yaml', 'service.yaml', 'ingress.yaml']
        };

        // Create main directories
        Object.keys(structure).forEach(dir => {
            const fullPath = path.join(this.githubPath, dir);
            if (!fs.existsSync(fullPath)) {
                fs.mkdirSync(fullPath, { recursive: true });
                console.log(`✅ Created: ${dir}`);
            }
        });

        // Create subdirectories
        Object.values(structure).flat().forEach(subdir => {
            const fullPath = path.join(this.githubPath, subdir);
            if (!fs.existsSync(fullPath)) {
                fs.mkdirSync(fullPath, { recursive: true });
                console.log(`✅ Created: ${subdir}`);
            }
        });
    }

    organizeCurrentFiles() {
        console.log('📋 Organizing current files...');
        
        const fileMapping = {
            // Core files
            'demo-server.js': 'src/',
            'package.json': '',
            'deploy.js': 'scripts/',
            'start.js': 'scripts/',
            
            // Configuration
            'config/database.js': 'config/',
            
            // Documentation
            'AWS-PRODUCTION-GUIDE.md': 'docs/',
            'DEPLOYMENT-COMPLETE-REPORT.md': 'docs/',
            
            // Public files
            'public/': 'public/',
            'public/create-transfer.html': 'public/',
            'public/dashboard.html': 'public/',
            
            // Source code
            'src/': 'src/',
            'src/server.js': 'src/',
            
            // Docker and Kubernetes
            'docker/': 'docker/',
            'k8s/': 'k8s/'
        };

        // Copy files based on mapping
        Object.keys(fileMapping).forEach(sourcePath => {
            const targetPath = fileMapping[sourcePath];
            this.copyFile(sourcePath, targetPath);
        });
    }

    copyFile(source, target) {
        const sourcePath = path.join(this.workspacePath, source);
        const targetPath = path.join(this.githubPath, target);
        
        if (fs.existsSync(sourcePath)) {
            try {
                if (fs.statSync(sourcePath).isDirectory()) {
                    // Copy directory
                    this.copyDirectory(sourcePath, targetPath);
                } else {
                    // Copy file
                    const content = fs.readFileSync(sourcePath, 'utf8');
                    fs.writeFileSync(targetPath, content);
                    this.transferredFiles.push(source);
                    console.log(`✅ Copied: ${source} -> ${target}`);
                }
            } catch (error) {
                this.issues.push(`Failed to copy ${source}: ${error.message}`);
                console.log(`❌ Failed: ${source}`);
            }
        }
    }

    copyDirectory(src, dest) {
        if (!fs.existsSync(dest)) {
            fs.mkdirSync(dest, { recursive: true });
        }

        const entries = fs.readdirSync(src, { withFileTypes: true });
        
        for (const entry of entries) {
            const srcPath = path.join(src, entry.name);
            const destPath = path.join(dest, entry.name);
            
            if (entry.isDirectory()) {
                this.copyDirectory(srcPath, destPath);
            } else {
                this.copyFile(srcPath, destPath);
            }
        }
    }

    createGitHubReadme() {
        console.log('📝 Creating GitHub README...');
        
        const readme = `# TransferSwift Global Banking System

🏦 Professional Banking Platform with AWS RDS Integration

## Features
- ✅ Multi-currency Support (21+ currencies)
- ✅ International Transfers (SWIFT/SEPA/ACH)
- ✅ Cryptocurrency Support
- ✅ Real-time Notifications
- ✅ Security & Compliance
- ✅ AWS Cloud Integration

## Quick Start
\`\`\`bash
# Local Demo
npm run dev

# Production with AWS
npm run deploy:production
\`\`\`

## Documentation
- [API Documentation](./docs/API.md)
- [Deployment Guide](./docs/DEPLOYMENT.md)
- [Architecture Overview](./docs/ARCHITECTURE.md)

## License
MIT License
`;

        fs.writeFileSync(path.join(this.githubPath, 'README.md'), readme);
        this.transferredFiles.push('README.md');
    }

    generateReport() {
        console.log('📊 Generating transfer report...');
        
        const report = {
            timestamp: new Date().toISOString(),
            totalFiles: this.transferredFiles.length,
            transferredFiles: this.transferredFiles,
            issues: this.issues,
            nextSteps: [
                'Upload files to GitHub repository',
                'Configure repository settings',
                'Set up CI/CD pipeline',
                'Configure environment variables',
                'Test deployment pipeline'
            ]
        };

        const reportContent = `# File Transfer Report

**Date**: ${report.timestamp}
**Total Files**: ${report.totalFiles}

## Transferred Files
${this.transferredFiles.map(file => `- ${file}`).join('\n')}

## Issues Encountered
${this.issues.length > 0 ? this.issues.map(issue => `- ${issue}`).join('\n') : 'No issues encountered'}

## Next Steps
${report.nextSteps.map(step => `- ${step}`).join('\n')}

## GitHub Upload Commands
\`\`\`bash
cd ${this.githubPath}
git init
git add .
git commit -m "Initial TransferSwift banking system"
git remote add origin <your-github-repo-url>
git push -u origin main
\`\`\`
`;

        fs.writeFileSync(path.join(this.githubPath, 'TRANSFER-REPORT.md'), reportContent);
        console.log('📋 Transfer report generated: TRANSFER-REPORT.md');
    }

    run() {
        console.log('🚀 Starting file organization process...');
        console.log('=' .repeat(50));
        
        // Create output directory
        if (!fs.existsSync(this.githubPath)) {
            fs.mkdirSync(this.githubPath, { recursive: true });
        }
        
        try {
            this.createDirectoryStructure();
            this.organizeCurrentFiles();
            this.createGitHubReadme();
            this.generateReport();
            
            console.log('=' .repeat(50));
            console.log('✅ File organization completed successfully!');
            console.log(`📁 Output directory: ${this.githubPath}`);
            console.log(`📄 Files transferred: ${this.transferredFiles.length}`);
            console.log(`⚠️  Issues found: ${this.issues.length}`);
            
        } catch (error) {
            console.error('❌ File organization failed:', error.message);
        }
    }
}

// Run the organizer
if (require.main === module) {
    const organizer = new FileOrganizer();
    organizer.run();
}

module.exports = FileOrganizer;