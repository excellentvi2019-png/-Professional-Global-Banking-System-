#!/usr/bin/env node

/**
 * Advanced File Archive and GitHub Upload Script
 * Creates a complete package ready for GitHub
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

class AdvancedFileArchiver {
    constructor() {
        this.sourcePath = path.join(__dirname, '..'); // Parent directory
        this.archivePath = '/workspace/transswift-github-archive';
        this.fileCount = 0;
        this.totalSize = 0;
        this.fileList = [];
    }

    createArchive() {
        console.log('📦 Creating GitHub archive...');
        
        if (fs.existsSync(this.archivePath)) {
            fs.rmSync(this.archivePath, { recursive: true });
        }
        fs.mkdirSync(this.archivePath, { recursive: true });

        // Process all files
        this.processDirectory(this.sourcePath, '');
        
        // Create manifest
        this.createManifest();
        
        // Create upload instructions
        this.createUploadInstructions();
        
        console.log(`✅ Archive created: ${this.archivePath}`);
        console.log(`📁 Files processed: ${this.fileCount}`);
        console.log(`💾 Total size: ${(this.totalSize / 1024 / 1024).toFixed(2)} MB`);
    }

    processDirectory(dir, relativePath) {
        const fullPath = path.join(this.sourcePath, dir);
        const items = fs.readdirSync(fullPath);

        for (const item of items) {
            const itemPath = path.join(fullPath, item);
            const itemRelativePath = path.join(relativePath, item);
            const targetPath = path.join(this.archivePath, itemRelativePath);

            const stats = fs.statSync(itemPath);

            if (stats.isDirectory()) {
                if (!fs.existsSync(targetPath)) {
                    fs.mkdirSync(targetPath, { recursive: true });
                }
                this.processDirectory(itemPath, itemRelativePath);
            } else {
                this.copyFile(itemPath, targetPath, itemRelativePath);
            }
        }
    }

    copyFile(source, target, relativePath) {
        try {
            const content = fs.readFileSync(source);
            fs.writeFileSync(target, content);
            
            const stats = fs.statSync(source);
            this.fileCount++;
            this.totalSize += stats.size;
            
            this.fileList.push({
                path: relativePath,
                size: stats.size,
                hash: this.getFileHash(content),
                modified: stats.mtime
            });
            
            console.log(`✅ Copied: ${relativePath} (${(stats.size/1024).toFixed(1)}KB)`);
        } catch (error) {
            console.log(`❌ Failed: ${relativePath} - ${error.message}`);
        }
    }

    getFileHash(content) {
        return crypto.createHash('md5').update(content).digest('hex');
    }

    createManifest() {
        const manifest = {
            createdAt: new Date().toISOString(),
            totalFiles: this.fileCount,
            totalSize: this.totalSize,
            files: this.fileList,
            uploadMethod: 'direct_upload',
            githubSteps: [
                '1. Create new repository on GitHub',
                '2. Clone repository locally',
                '3. Copy files from archive to repository',
                '4. Commit and push to GitHub'
            ]
        };

        const manifestPath = path.join(this.archivePath, 'MANIFEST.json');
        fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2));
        console.log('📋 Manifest created: MANIFEST.json');
    }

    createUploadInstructions() {
        const instructions = `# TransferSwift GitHub Upload Instructions

## 📦 Archive Contents
- **Total Files**: ${this.fileCount}
- **Total Size**: ${(this.totalSize / 1024 / 1024).toFixed(2)} MB
- **Created**: ${new Date().toISOString()}

## 🚀 Upload Methods

### Method 1: Direct Git Upload (Recommended)
\`\`\`bash
# 1. Create repository on GitHub.com
# Repository name: transferswift-banking

# 2. Clone and upload
git clone <your-repository-url>
cd <repository-name>
cp -r ${this.archivePath}/* .
git add .
git commit -m "Initial TransferSwift Banking System"
git push origin main
\`\`\`

### Method 2: GitHub CLI
\`\`\`bash
# Install GitHub CLI if not installed
# https://cli.github.com/

# Create repository
gh repo create transferswift-banking --public

# Copy files
cp -r ${this.archivePath}/* .

# Commit and push
git add .
git commit -m "TransferSwift Banking System v2.0.0"
git push origin main
\`\`\`

### Method 3: Manual Upload
1. Go to GitHub.com and create new repository
2. Go to "uploading an existing file" option
3. Drag and drop files from archive
4. Add commit message
5. Commit changes

## 📁 Directory Structure
\`\`\`
transferswift-banking/
├── src/                    # Source code
│   ├── models/             # Data models
│   ├── routes/             # API routes
│   └── server.js           # Main server
├── public/                 # Frontend files
│   ├── dashboard.html      # Main dashboard
│   ├── create-transfer.html # Transfer form
│   └── assets/             # Static assets
├── config/                 # Configuration files
├── docs/                   # Documentation
├── tests/                  # Test files
├── docker/                 # Docker files
├── k8s/                    # Kubernetes configs
├── package.json            # Node.js dependencies
├── demo-server.js          # Standalone demo server
├── deploy.js               # Deployment script
└── README.md               # Project description
\`\`\`

## 🔧 Post-Upload Setup
1. **Enable GitHub Pages** (optional)
2. **Configure Branch Protection** (main branch)
3. **Set up GitHub Actions** (CI/CD)
4. **Add Secrets** (environment variables)
5. **Configure Repository Settings**

## 🌐 System URLs
After upload and deployment:
- **Dashboard**: https://yourusername.github.io/transferswift-banking/dashboard
- **API**: https://yourusername.github.io/transferswift-banking/api
- **Health Check**: https://yourusername.github.io/transferswift-banking/health

## 📞 Support
- Check the MANIFEST.json for file details
- Use GitHub Issues for tracking progress
- Review DEPLOYMENT-COMPLETE-REPORT.md for detailed setup

## ✅ Verification Checklist
- [ ] All files uploaded successfully
- [ ] Repository structure matches manifest
- [ ] README.md displays properly
- [ ] GitHub Pages enabled (if needed)
- [ ] Repository made public (if desired)
- [ ] Issues enabled for tracking
- [ ] Wiki created (optional)
`;

        const instructionsPath = path.join(this.archivePath, 'UPLOAD-INSTRUCTIONS.md');
        fs.writeFileSync(instructionsPath, instructions);
        console.log('📖 Upload instructions created: UPLOAD-INSTRUCTIONS.md');
    }
}

// Run the archiver
if (require.main === module) {
    const archiver = new AdvancedFileArchiver();
    archiver.createArchive();
}

module.exports = AdvancedFileArchiver;