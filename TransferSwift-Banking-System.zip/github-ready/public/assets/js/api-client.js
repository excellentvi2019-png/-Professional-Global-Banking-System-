/**
 * TransferSwift API Client
 * Global Banking System API Client
 * Version 2.0.0
 */

class TransferSwiftAPI {
    constructor() {
        this.baseURL = this.getApiBaseUrl();
        this.token = localStorage.getItem('authToken');
        this.isAuthenticated = false;
        this.demoMode = localStorage.getItem('demoMode') === 'true';
        this.requestQueue = [];
        this.retryAttempts = 3;
        this.timeout = 30000; // 30 seconds
        this.rateLimiter = {
            requests: 0,
            windowStart: Date.now(),
            maxRequests: 100
        };
    }

    // Get API base URL
    getApiBaseUrl() {
        if (typeof window !== 'undefined') {
            const protocol = window.location.protocol;
            const host = window.location.hostname;
            const port = process.env.NODE_ENV === 'production' ? '' : ':9000';
            return `${protocol}//${host}${port}/api`;
        }
        return 'http://localhost:9000/api';
    }

    // Initialize API client
    async initialize() {
        try {
            await this.checkConnection();
            if (this.token) {
                await this.verifyToken();
            }
        } catch (error) {
            console.warn('API client initialization failed, switching to demo mode');
            this.enableDemoMode();
        }
    }

    // Check connection to API server
    async checkConnection() {
        try {
            const response = await this.makeRequest('/health', 'GET', null, false);
            this.isAuthenticated = true;
            return true;
        } catch (error) {
            throw new Error('API server not available');
        }
    }

    // Verify authentication token
    async verifyToken() {
        try {
            const response = await this.makeRequest('/auth/verify', 'GET');
            this.isAuthenticated = true;
            return response;
        } catch (error) {
            this.logout();
            throw error;
        }
    }

    // Enable demo mode
    enableDemoMode() {
        this.demoMode = true;
        this.isAuthenticated = true;
        localStorage.setItem('demoMode', 'true');
    }

    // Generic request method with retry logic
    async makeRequest(endpoint, method = 'GET', data = null, requireAuth = true, retryCount = 0) {
        // Rate limiting check
        if (!this.checkRateLimit()) {
            throw new Error('Rate limit exceeded');
        }

        const url = `${this.baseURL}${endpoint}`;
        const config = {
            method,
            headers: {
                'Content-Type': 'application/json',
                ...(requireAuth && this.token && { 'Authorization': `Bearer ${this.token}` })
            },
            timeout: this.timeout
        };

        if (data && (method === 'POST' || method === 'PUT' || method === 'PATCH')) {
            config.body = JSON.stringify(data);
        }

        try {
            const response = await fetch(url, config);
            
            if (response.status === 401 && requireAuth) {
                this.logout();
                throw new Error('Authentication required');
            }

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(errorData.error || `HTTP ${response.status}`);
            }

            const responseData = await response.json();
            this.updateRateLimit();
            return responseData;

        } catch (error) {
            if (error.name === 'TypeError' && error.message.includes('fetch')) {
                // Network error, try demo mode or retry
                if (this.demoMode && retryCount < this.retryAttempts) {
                    return this.handleDemoRequest(endpoint, method, data);
                }
                
                if (!this.demoMode && retryCount < this.retryAttempts) {
                    console.log(`Retrying request (${retryCount + 1}/${this.retryAttempts})...`);
                    await this.delay(1000 * (retryCount + 1));
                    return this.makeRequest(endpoint, method, data, requireAuth, retryCount + 1);
                }
            }
            
            throw error;
        }
    }

    // Handle demo requests
    async handleDemoRequest(endpoint, method, data) {
        await this.delay(200); // Simulate network delay
        
        const handlers = {
            '/auth/login': () => this.handleDemoLogin(data),
            '/auth/register': () => this.handleDemoRegister(data),
            '/auth/verify': () => this.handleDemoVerify(),
            '/accounts': () => this.handleDemoAccounts(),
            '/accounts/balances': () => this.handleDemoBalances(),
            '/transfers': () => this.handleDemoTransfers(method, data),
            '/transfers/': (id) => this.handleDemoTransferDetails(id),
            '/dashboard/stats': () => this.handleDemoStats()
        };

        for (const [pattern, handler] of Object.entries(handlers)) {
            if (endpoint.startsWith(pattern)) {
                if (pattern === '/transfers/' && endpoint.includes('/')) {
                    const parts = endpoint.split('/');
                    const id = parts[parts.length - 1];
                    return handler(id);
                }
                return handler();
            }
        }

        return { success: true, data: {}, demoMode: true };
    }

    // Check rate limiting
    checkRateLimit() {
        const now = Date.now();
        const windowMs = 60000; // 1 minute

        if (now - this.rateLimiter.windowStart > windowMs) {
            this.rateLimiter = { requests: 0, windowStart: now, maxRequests: 100 };
        }

        if (this.rateLimiter.requests >= this.rateLimiter.maxRequests) {
            return false;
        }

        return true;
    }

    // Update rate limiter
    updateRateLimit() {
        this.rateLimiter.requests++;
    }

    // Add delay for retry
    delay(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    // =============================================
    // Authentication Methods
    // =============================================

    async login(email, password) {
        return await this.makeRequest('/auth/login', 'POST', { email, password }, false);
    }

    async register(userData) {
        return await this.makeRequest('/auth/register', 'POST', userData, false);
    }

    async verifyToken() {
        return await this.makeRequest('/auth/verify', 'GET');
    }

    async forgotPassword(email) {
        return await this.makeRequest('/auth/forgot-password', 'POST', { email }, false);
    }

    async logout() {
        try {
            await this.makeRequest('/auth/logout', 'POST');
        } catch (error) {
            console.warn('Logout request failed:', error);
        } finally {
            this.clearAuth();
        }
    }

    clearAuth() {
        this.token = null;
        this.isAuthenticated = false;
        localStorage.removeItem('authToken');
        localStorage.removeItem('userData');
        localStorage.removeItem('demoMode');
    }

    // =============================================
    // Account Methods
    // =============================================

    async getAccounts() {
        return await this.makeRequest('/accounts');
    }

    async getAccountBalances() {
        return await this.makeRequest('/accounts/balances');
    }

    async getAccountDetails(accountId) {
        return await this.makeRequest(`/accounts/${accountId}`);
    }

    async createAccount(accountData) {
        return await this.makeRequest('/accounts', 'POST', accountData);
    }

    async updateAccount(accountId, updateData) {
        return await this.makeRequest(`/accounts/${accountId}`, 'PUT', updateData);
    }

    async freezeAccount(accountId, reason) {
        return await this.makeRequest(`/accounts/${accountId}/freeze`, 'POST', { reason });
    }

    async unfreezeAccount(accountId) {
        return await this.makeRequest(`/accounts/${accountId}/unfreeze`, 'POST');
    }

    // =============================================
    // Transfer Methods
    // =============================================

    async createTransfer(transferData) {
        return await this.makeRequest('/transfers', 'POST', transferData);
    }

    async getTransfers(filters = {}) {
        const queryParams = new URLSearchParams(filters).toString();
        const endpoint = `/transfers${queryParams ? `?${queryParams}` : ''}`;
        return await this.makeRequest(endpoint);
    }

    async getTransferDetails(transactionId) {
        return await this.makeRequest(`/transfers/${transactionId}`);
    }

    async getTransferStatus(transactionId) {
        return await this.makeRequest(`/transfers/${transactionId}/status`);
    }

    async verifyTransfer(transactionId, verificationCode) {
        return await this.makeRequest(`/transfers/${transactionId}/verify`, 'POST', { code: verificationCode });
    }

    async confirmTransfer(transactionId) {
        return await this.makeRequest(`/transfers/${transactionId}/confirm`, 'POST');
    }

    async cancelTransfer(transactionId, reason) {
        return await this.makeRequest(`/transfers/${transactionId}/cancel`, 'POST', { reason });
    }

    async getTransferHistory(filters = {}) {
        const queryParams = new URLSearchParams({
            ...filters,
            type: 'history'
        }).toString();
        return await this.makeRequest(`/transfers?${queryParams}`);
    }

    // =============================================
    // Dashboard Methods
    // =============================================

    async getDashboardStats() {
        return await this.makeRequest('/dashboard/stats');
    }

    async getRecentActivity() {
        return await this.makeRequest('/dashboard/activity');
    }

    async getAccountSummary() {
        return await this.makeRequest('/dashboard/summary');
    }

    // =============================================
    // Virtual Card Methods
    // =============================================

    async getVirtualCards() {
        return await this.makeRequest('/virtual-cards');
    }

    async createVirtualCard(cardData) {
        return await this.makeRequest('/virtual-cards', 'POST', cardData);
    }

    async updateVirtualCard(cardId, updateData) {
        return await this.makeRequest(`/virtual-cards/${cardId}`, 'PUT', updateData);
    }

    async deleteVirtualCard(cardId) {
        return await this.makeRequest(`/virtual-cards/${cardId}`, 'DELETE');
    }

    async freezeVirtualCard(cardId, reason) {
        return await this.makeRequest(`/virtual-cards/${cardId}/freeze`, 'POST', { reason });
    }

    async unfreezeVirtualCard(cardId) {
        return await this.makeRequest(`/virtual-cards/${cardId}/unfreeze`, 'POST');
    }

    // =============================================
    // Crypto Methods
    // =============================================

    async getCryptoWallets() {
        return await this.makeRequest('/crypto-wallets');
    }

    async getCryptoBalance() {
        return await this.makeRequest('/crypto/balance');
    }

    async createCryptoTransfer(transferData) {
        return await this.makeRequest('/crypto/transfer', 'POST', transferData);
    }

    async getExchangeRates(fromCurrency, toCurrency) {
        return await this.makeRequest(`/crypto/rates?from=${fromCurrency}&to=${toCurrency}`);
    }

    // =============================================
    // Notification Methods
    // =============================================

    async getNotifications() {
        return await this.makeRequest('/notifications');
    }

    async markNotificationAsRead(notificationId) {
        return await this.makeRequest(`/notifications/${notificationId}/read`, 'POST');
    }

    async markAllNotificationsAsRead() {
        return await this.makeRequest('/notifications/read-all', 'POST');
    }

    async updateNotificationSettings(settings) {
        return await this.makeRequest('/notifications/settings', 'PUT', settings);
    }

    // =============================================
    // Demo Mode Handlers
    // =============================================

    handleDemoLogin(data) {
        const { email, password } = data;
        const validUsers = [
            { email: 'swift@transswift.finance', password: 'admin123', name: 'System Administrator', id: 'admin-001', role: 'admin' },
            { email: 'demo@transswift.sy', password: 'demo123', name: 'Demo User', id: 'demo-001', role: 'user' }
        ];

        const user = validUsers.find(u => u.email === email && u.password === password);
        
        if (user) {
            const token = `demo_token_${Date.now()}`;
            return {
                success: true,
                token,
                data: {
                    userId: user.id,
                    email: user.email,
                    name: user.name,
                    role: user.role
                },
                demoMode: true
            };
        }
        
        throw new Error('بيانات تسجيل دخول غير صحيحة');
    }

    handleDemoRegister(data) {
        const userId = `demo_user_${Date.now()}`;
        return {
            success: true,
            message: 'تم إنشاء الحساب بنجاح',
            data: {
                userId,
                email: data.email,
                name: data.firstName + ' ' + data.lastName,
                role: 'user'
            },
            demoMode: true
        };
    }

    handleDemoVerify() {
        return {
            success: true,
            data: {
                userId: 'demo-user-001',
                email: 'demo@transswift.sy',
                name: 'Demo User',
                role: 'user'
            },
            demoMode: true
        };
    }

    handleDemoAccounts() {
        return {
            success: true,
            data: {
                accounts: [
                    {
                        accountId: 'acc-001',
                        accountNumber: '1234567890123456',
                        bankName: 'Saudi National Bank',
                        currency: 'USD',
                        balance: 50000.00,
                        availableBalance: 45000.00,
                        status: 'active'
                    },
                    {
                        accountId: 'acc-002',
                        accountNumber: '9876543210987654',
                        bankName: 'Emirates NBD',
                        currency: 'AED',
                        balance: 180000.00,
                        availableBalance: 175000.00,
                        status: 'active'
                    }
                ]
            },
            demoMode: true
        };
    }

    handleDemoBalances() {
        return {
            success: true,
            data: {
                balances: [
                    { currency: 'USD', amount: 50000.00 },
                    { currency: 'AED', amount: 180000.00 },
                    { currency: 'EUR', amount: 25000.00 }
                ],
                totalUSD: 87500.00
            },
            demoMode: true
        };
    }

    handleDemoTransfers(method, data) {
        if (method === 'GET') {
            return {
                success: true,
                data: {
                    transfers: [
                        {
                            transactionId: 'TX001',
                            amount: 1000,
                            currency: 'USD',
                            status: 'completed',
                            recipientName: 'Ahmed Al-Rashid',
                            requestedAt: new Date().toISOString()
                        },
                        {
                            transactionId: 'TX002',
                            amount: 5000,
                            currency: 'AED',
                            status: 'processing',
                            recipientName: 'Fatima Hassan',
                            requestedAt: new Date(Date.now() - 3600000).toISOString()
                        }
                    ]
                },
                demoMode: true
            };
        } else if (method === 'POST') {
            const transactionId = `TX${Date.now()}`;
            return {
                success: true,
                data: {
                    transfer: {
                        transactionId,
                        amount: data.amount,
                        currency: data.currency,
                        status: 'pending',
                        recipientName: data.recipientName,
                        requestedAt: new Date().toISOString()
                    },
                    nextStep: data.amount >= 1000 ? 'verification_required' : 'confirmation_required'
                },
                demoMode: true
            };
        }
        
        return { success: true, data: {}, demoMode: true };
    }

    handleDemoTransferDetails(id) {
        return {
            success: true,
            data: {
                transfer: {
                    transactionId: id,
                    amount: 1000,
                    currency: 'USD',
                    status: 'completed',
                    recipientName: 'Demo Recipient',
                    requestedAt: new Date().toISOString()
                },
                tracking: [
                    {
                        location: 'TransferSwift System',
                        timestamp: new Date().toISOString(),
                        status: 'completed',
                        description: 'تم إنجاز التحويل بنجاح'
                    }
                ]
            },
            demoMode: true
        };
    }

    handleDemoStats() {
        return {
            success: true,
            data: {
                totalBalance: 87500.00,
                activeTransfers: 2,
                monthlyVolume: 125000.00,
                securityScore: 95
            },
            demoMode: true
        };
    }

    // =============================================
    // Utility Methods
    // =============================================

    // Get current user data
    getCurrentUser() {
        const userData = localStorage.getItem('userData');
        return userData ? JSON.parse(userData) : null;
    }

    // Set authentication token
    setAuthToken(token, userData) {
        this.token = token;
        this.isAuthenticated = true;
        localStorage.setItem('authToken', token);
        localStorage.setItem('userData', JSON.stringify(userData));
    }

    // Check if user is authenticated
    isUserAuthenticated() {
        return this.isAuthenticated || this.demoMode;
    }

    // Format currency
    formatCurrency(amount, currency = 'USD') {
        const currencySymbols = {
            'USD': '$', 'EUR': '€', 'GBP': '£', 'SAR': 'ر.س',
            'AED': 'د.إ', 'KWD': 'د.ك', 'BHD': '.د.ب', 'QAR': 'ر.ق',
            'JOD': 'د.أ', 'EGP': 'ج.م', 'SYP': 'ل.س', 'LBP': 'ل.ل',
            'CAD': 'C$', 'AUD': 'A$', 'CHF': 'Fr', 'JPY': '¥',
            'CNY': '¥', 'INR': '₹', 'BTC': '₿', 'ETH': 'Ξ', 'USDT': '$'
        };

        const symbol = currencySymbols[currency] || currency;
        const formattedAmount = parseFloat(amount).toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        return `${symbol}${formattedAmount}`;
    }

    // Format date
    formatDate(dateString, options = {}) {
        const date = new Date(dateString);
        return date.toLocaleDateString('ar-SA', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            ...options
        });
    }

    // Generate unique ID
    generateId() {
        return `${Date.now()}${Math.random().toString(36).substr(2, 9)}`;
    }

    // Validate email
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Validate phone number
    isValidPhone(phone) {
        const phoneRegex = /^\+?[1-9]\d{1,14}$/;
        return phoneRegex.test(phone.replace(/\s/g, ''));
    }

    // Sanitize input
    sanitizeInput(input) {
        if (typeof input !== 'string') return input;
        return input
            .replace(/[<>]/g, '') // Remove HTML tags
            .trim(); // Remove whitespace
    }

    // Debounce function
    debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Retry function with exponential backoff
    async retry(fn, maxAttempts = 3, baseDelay = 1000) {
        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                return await fn();
            } catch (error) {
                if (attempt === maxAttempts) {
                    throw error;
                }
                
                const delay = baseDelay * Math.pow(2, attempt - 1);
                await this.delay(delay);
            }
        }
    }

    // Cache management
    setCache(key, data, ttl = 300000) { // 5 minutes default TTL
        const cacheItem = {
            data,
            timestamp: Date.now(),
            ttl
        };
        localStorage.setItem(`cache_${key}`, JSON.stringify(cacheItem));
    }

    getCache(key) {
        const cached = localStorage.getItem(`cache_${key}`);
        if (!cached) return null;

        try {
            const { data, timestamp, ttl } = JSON.parse(cached);
            if (Date.now() - timestamp > ttl) {
                localStorage.removeItem(`cache_${key}`);
                return null;
            }
            return data;
        } catch (error) {
            localStorage.removeItem(`cache_${key}`);
            return null;
        }
    }

    clearCache(pattern = '') {
        const keys = Object.keys(localStorage);
        keys.forEach(key => {
            if (key.startsWith('cache_') && (!pattern || key.includes(pattern))) {
                localStorage.removeItem(key);
            }
        });
    }
}

// Create global instance
window.apiClient = new TransferSwiftAPI();

// Initialize on page load
if (typeof window !== 'undefined') {
    window.addEventListener('load', async () => {
        try {
            await window.apiClient.initialize();
            console.log('API client initialized successfully');
        } catch (error) {
            console.warn('API client initialization failed:', error);
        }
    });
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = TransferSwiftAPI;
}