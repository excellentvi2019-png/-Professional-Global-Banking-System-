/**
 * TransferSwift Notification System
 * Real-time notifications for global banking
 * Version 2.0.0
 */

class NotificationSystem {
    constructor() {
        this.socket = null;
        this.notifications = [];
        this.settings = {
            email: true,
            sms: true,
            push: true,
            inApp: true,
            sound: true,
            desktop: true
        };
        this.soundEnabled = true;
        this.initialized = false;
    }

    // Initialize notification system
    async initialize() {
        try {
            await this.setupSocketConnection();
            await this.setupServiceWorker();
            await this.loadSettings();
            await this.requestPermissions();
            this.initialized = true;
            console.log('Notification system initialized successfully');
        } catch (error) {
            console.warn('Notification system initialization failed:', error);
        }
    }

    // Setup Socket.IO connection
    setupSocketConnection() {
        return new Promise((resolve, reject) => {
            try {
                // Check if Socket.IO is available
                if (typeof io === 'undefined') {
                    console.warn('Socket.IO not available');
                    resolve();
                    return;
                }

                const token = localStorage.getItem('authToken');
                if (!token) {
                    resolve();
                    return;
                }

                this.socket = io({
                    auth: { token }
                });

                this.socket.on('connect', () => {
                    console.log('Connected to notification server');
                    // Authenticate with token
                    this.socket.emit('authenticate', token);
                });

                this.socket.on('authenticated', (data) => {
                    console.log('Socket authenticated:', data);
                });

                this.socket.on('notification', (notification) => {
                    this.handleNotification(notification);
                });

                this.socket.on('transfer_update', (data) => {
                    this.showTransferUpdate(data);
                });

                this.socket.on('balance_update', (data) => {
                    this.showBalanceUpdate(data);
                });

                this.socket.on('security_alert', (data) => {
                    this.showSecurityAlert(data);
                });

                this.socket.on('disconnect', () => {
                    console.log('Disconnected from notification server');
                });

                resolve();
            } catch (error) {
                reject(error);
            }
        });
    }

    // Setup Service Worker for push notifications
    async setupServiceWorker() {
        if ('serviceWorker' in navigator && 'PushManager' in window) {
            try {
                const registration = await navigator.serviceWorker.register('/sw.js');
                console.log('Service Worker registered:', registration);
                return registration;
            } catch (error) {
                console.warn('Service Worker registration failed:', error);
            }
        }
    }

    // Load notification settings
    async loadSettings() {
        try {
            const savedSettings = localStorage.getItem('notificationSettings');
            if (savedSettings) {
                this.settings = { ...this.settings, ...JSON.parse(savedSettings) };
            }
        } catch (error) {
            console.warn('Failed to load notification settings:', error);
        }
    }

    // Request notification permissions
    async requestPermissions() {
        if ('Notification' in window) {
            const permission = await Notification.requestPermission();
            
            if (permission === 'granted') {
                console.log('Notification permission granted');
                this.settings.push = true;
            } else {
                console.log('Notification permission denied');
                this.settings.push = false;
            }
        }
    }

    // Handle incoming notification
    handleNotification(notification) {
        // Store notification
        this.notifications.unshift({
            ...notification,
            id: this.generateId(),
            timestamp: new Date().toISOString(),
            read: false
        });

        // Limit stored notifications
        if (this.notifications.length > 100) {
            this.notifications = this.notifications.slice(0, 100);
        }

        // Show notification based on type
        this.showNotification(notification);
        
        // Play sound if enabled
        if (this.settings.sound) {
            this.playNotificationSound(notification.type);
        }
        
        // Show desktop notification if enabled
        if (this.settings.desktop && 'Notification' in window && Notification.permission === 'granted') {
            this.showDesktopNotification(notification);
        }
        
        // Update UI
        this.updateNotificationBadge();
        this.updateNotificationList();
    }

    // Show notification in app
    showNotification(notification) {
        const container = this.getNotificationContainer();
        if (!container) return;

        const notificationElement = this.createNotificationElement(notification);
        container.appendChild(notificationElement);

        // Auto-remove after delay
        setTimeout(() => {
            this.removeNotificationElement(notificationElement);
        }, 5000);

        // Add to notification list
        this.addToNotificationList(notification);
    }

    // Create notification element
    createNotificationElement(notification) {
        const element = document.createElement('div');
        element.className = `notification notification-${notification.type}`;
        element.innerHTML = `
            <div class="notification-content">
                <div class="notification-icon">
                    <i class="${this.getNotificationIcon(notification.type)}"></i>
                </div>
                <div class="notification-text">
                    <div class="notification-title">${notification.title}</div>
                    <div class="notification-message">${notification.message}</div>
                </div>
                <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="notification-time">${this.formatTime(new Date())}</div>
        `;

        // Add animation
        setTimeout(() => {
            element.classList.add('show');
        }, 10);

        return element;
    }

    // Get notification icon
    getNotificationIcon(type) {
        const icons = {
            'success': 'fas fa-check-circle',
            'error': 'fas fa-exclamation-circle',
            'warning': 'fas fa-exclamation-triangle',
            'info': 'fas fa-info-circle',
            'transfer_created': 'fas fa-plus-circle',
            'transfer_completed': 'fas fa-check-circle',
            'transfer_failed': 'fas fa-times-circle',
            'balance_update': 'fas fa-wallet',
            'security_alert': 'fas fa-shield-alt',
            'reminder': 'fas fa-bell'
        };
        return icons[type] || 'fas fa-bell';
    }

    // Show desktop notification
    showDesktopNotification(notification) {
        const desktopNotification = new Notification(notification.title, {
            body: notification.message,
            icon: '/assets/icons/notification-icon.png',
            tag: notification.type,
            requireInteraction: notification.type === 'security_alert'
        });

        desktopNotification.onclick = () => {
            window.focus();
            desktopNotification.close();
        };

        // Auto-close after 10 seconds unless it's a security alert
        if (notification.type !== 'security_alert') {
            setTimeout(() => {
                desktopNotification.close();
            }, 10000);
        }
    }

    // Play notification sound
    playNotificationSound(type) {
        if (!this.soundEnabled) return;

        try {
            const audio = new Audio(`/assets/sounds/${type}.mp3`);
            audio.volume = 0.3;
            audio.play().catch(error => {
                console.warn('Failed to play notification sound:', error);
            });
        } catch (error) {
            console.warn('Failed to create notification sound:', error);
        }
    }

    // Get notification container
    getNotificationContainer() {
        let container = document.getElementById('notification-container');
        
        if (!container) {
            container = document.createElement('div');
            container.id = 'notification-container';
            container.className = 'notification-container';
            container.innerHTML = '';
            document.body.appendChild(container);
        }

        return container;
    }

    // Remove notification element
    removeNotificationElement(element) {
        element.classList.add('removing');
        setTimeout(() => {
            if (element.parentNode) {
                element.parentNode.removeChild(element);
            }
        }, 300);
    }

    // Add to notification list
    addToNotificationList(notification) {
        const list = this.getNotificationList();
        if (!list) return;

        const listItem = document.createElement('div');
        listItem.className = 'notification-list-item';
        listItem.innerHTML = `
            <div class="notification-list-icon">
                <i class="${this.getNotificationIcon(notification.type)}"></i>
            </div>
            <div class="notification-list-content">
                <div class="notification-list-title">${notification.title}</div>
                <div class="notification-list-message">${notification.message}</div>
                <div class="notification-list-time">${this.formatTime(new Date())}</div>
            </div>
        `;

        list.insertBefore(listItem, list.firstChild);

        // Limit items in list
        const items = list.querySelectorAll('.notification-list-item');
        if (items.length > 20) {
            list.removeChild(items[items.length - 1]);
        }
    }

    // Get notification list
    getNotificationList() {
        return document.getElementById('notification-list');
    }

    // Update notification badge
    updateNotificationBadge() {
        const badge = document.getElementById('notification-badge');
        if (!badge) return;

        const unreadCount = this.notifications.filter(n => !n.read).length;
        
        if (unreadCount > 0) {
            badge.textContent = unreadCount > 99 ? '99+' : unreadCount.toString();
            badge.style.display = 'inline-block';
        } else {
            badge.style.display = 'none';
        }
    }

    // Update notification list
    updateNotificationList() {
        // This would update the notification panel if it's open
        const event = new CustomEvent('notificationListUpdate');
        document.dispatchEvent(event);
    }

    // Show transfer update
    showTransferUpdate(data) {
        const { type, transactionId, status, amount, currency } = data;
        
        let title, message, notificationType = 'info';
        
        switch (type) {
            case 'transfer_created':
                title = 'تحويل جديد';
                message = `تم إنشاء تحويل بقيمة ${amount} ${currency}`;
                notificationType = 'info';
                break;
            case 'transfer_verified':
                title = 'تم التحقق من التحويل';
                message = `تم التحقق من التحويل ${transactionId}`;
                notificationType = 'success';
                break;
            case 'transfer_completed':
                title = 'تم إنجاز التحويل';
                message = `تم إنجاز التحويل ${transactionId} بنجاح`;
                notificationType = 'success';
                break;
            case 'transfer_failed':
                title = 'فشل التحويل';
                message = `فشل في إنجاز التحويل ${transactionId}`;
                notificationType = 'error';
                break;
            case 'transfer_cancelled':
                title = 'تم إلغاء التحويل';
                message = `تم إلغاء التحويل ${transactionId}`;
                notificationType = 'warning';
                break;
        }

        this.handleNotification({
            type: notificationType,
            title,
            message,
            data
        });
    }

    // Show balance update
    showBalanceUpdate(data) {
        this.handleNotification({
            type: 'info',
            title: 'تحديث الرصيد',
            message: `تم تحديث رصيد الحساب إلى ${this.formatCurrency(data.newBalance, data.currency)}`,
            data
        });
    }

    // Show security alert
    showSecurityAlert(data) {
        this.handleNotification({
            type: 'security_alert',
            title: 'تنبيه أمني',
            message: data.message,
            data
        });
    }

    // Mark notification as read
    markAsRead(notificationId) {
        const notification = this.notifications.find(n => n.id === notificationId);
        if (notification) {
            notification.read = true;
            this.updateNotificationBadge();
            this.updateNotificationList();
        }
    }

    // Mark all notifications as read
    markAllAsRead() {
        this.notifications.forEach(notification => {
            notification.read = true;
        });
        this.updateNotificationBadge();
        this.updateNotificationList();
    }

    // Get all notifications
    getNotifications() {
        return this.notifications;
    }

    // Get unread notifications
    getUnreadNotifications() {
        return this.notifications.filter(n => !n.read);
    }

    // Get notification by ID
    getNotification(notificationId) {
        return this.notifications.find(n => n.id === notificationId);
    }

    // Update settings
    updateSettings(newSettings) {
        this.settings = { ...this.settings, ...newSettings };
        localStorage.setItem('notificationSettings', JSON.stringify(this.settings));
        
        // Update UI if needed
        this.updateNotificationSettingsUI();
    }

    // Update notification settings UI
    updateNotificationSettingsUI() {
        const settings = this.settings;
        
        // Update checkboxes
        Object.keys(settings).forEach(key => {
            const checkbox = document.getElementById(`notification-${key}`);
            if (checkbox) {
                checkbox.checked = settings[key];
            }
        });
    }

    // Test notification
    testNotification() {
        this.handleNotification({
            type: 'info',
            title: 'اختبار الإشعارات',
            message: 'هذا اختبار لنظام الإشعارات',
            data: { test: true }
        });
    }

    // Clear all notifications
    clearAll() {
        this.notifications = [];
        this.updateNotificationBadge();
        this.updateNotificationList();
        
        // Clear UI
        const container = this.getNotificationContainer();
        if (container) {
            container.innerHTML = '';
        }
        
        const list = this.getNotificationList();
        if (list) {
            list.innerHTML = '';
        }
    }

    // Send notification via API
    async sendNotification(notificationData) {
        try {
            const response = await apiClient.post('/notifications', notificationData);
            return response;
        } catch (error) {
            console.error('Failed to send notification:', error);
            throw error;
        }
    }

    // Schedule notification
    scheduleNotification(notificationData, delay) {
        setTimeout(() => {
            this.handleNotification(notificationData);
        }, delay);
    }

    // Utility functions
    generateId() {
        return `${Date.now()}${Math.random().toString(36).substr(2, 9)}`;
    }

    formatTime(date) {
        return date.toLocaleTimeString('ar-SA', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    formatCurrency(amount, currency = 'USD') {
        if (window.apiClient && window.apiClient.formatCurrency) {
            return window.apiClient.formatCurrency(amount, currency);
        }
        
        const currencySymbols = {
            'USD': '$', 'EUR': '€', 'GBP': '£', 'SAR': 'ر.س',
            'AED': 'د.إ', 'KWD': 'د.ك', 'BHD': '.د.ب', 'QAR': 'ر.ق',
            'JOD': 'د.أ', 'EGP': 'ج.م', 'SYP': 'ل.س', 'LBP': 'ل.ل',
            'CAD': 'C$', 'AUD': 'A$', 'CHF': 'Fr', 'JPY': '¥',
            'CNY': '¥', 'INR': '₹', 'BTC': '₿', 'ETH': 'Ξ', 'USDT': '$'
        };

        const symbol = currencySymbols[currency] || currency;
        const formattedAmount = parseFloat(amount).toLocaleString('en-US', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });

        return `${symbol}${formattedAmount}`;
    }

    // Toggle sound
    toggleSound() {
        this.soundEnabled = !this.soundEnabled;
        localStorage.setItem('notificationSound', this.soundEnabled.toString());
        return this.soundEnabled;
    }

    // Check if initialized
    isInitialized() {
        return this.initialized;
    }

    // Cleanup
    destroy() {
        if (this.socket) {
            this.socket.disconnect();
            this.socket = null;
        }
        
        this.notifications = [];
        this.initialized = false;
        
        console.log('Notification system destroyed');
    }
}

// CSS Styles for Notifications (to be added to CSS file)
const notificationStyles = `
.notification-container {
    position: fixed;
    top: 20px;
    right: 20px;
    z-index: 10000;
    max-width: 400px;
    pointer-events: none;
}

.notification {
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
    margin-bottom: 12px;
    padding: 16px;
    transform: translateX(100%);
    transition: all 0.3s ease;
    pointer-events: auto;
    border-left: 4px solid #2196F3;
    opacity: 0;
}

.notification.show {
    transform: translateX(0);
    opacity: 1;
}

.notification.removing {
    transform: translateX(100%);
    opacity: 0;
}

.notification-success {
    border-left-color: #4CAF50;
}

.notification-error {
    border-left-color: #F44336;
}

.notification-warning {
    border-left-color: #FF9800;
}

.notification-info {
    border-left-color: #2196F3;
}

.notification-security_alert {
    border-left-color: #FF5722;
    background: linear-gradient(135deg, #fff3e0, #ffecb3);
    animation: pulse 2s infinite;
}

@keyframes pulse {
    0% { box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15); }
    50% { box-shadow: 0 10px 35px rgba(255, 87, 34, 0.3); }
    100% { box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15); }
}

.notification-content {
    display: flex;
    align-items: flex-start;
    gap: 12px;
}

.notification-icon {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 16px;
    color: white;
    flex-shrink: 0;
}

.notification-success .notification-icon {
    background: linear-gradient(135deg, #4CAF50, #45a049);
}

.notification-error .notification-icon {
    background: linear-gradient(135deg, #F44336, #e53935);
}

.notification-warning .notification-icon {
    background: linear-gradient(135deg, #FF9800, #f57c00);
}

.notification-info .notification-icon {
    background: linear-gradient(135deg, #2196F3, #1976d2);
}

.notification-security_alert .notification-icon {
    background: linear-gradient(135deg, #FF5722, #e64a19);
}

.notification-text {
    flex: 1;
}

.notification-title {
    font-weight: 600;
    color: #212121;
    margin-bottom: 4px;
    font-size: 14px;
}

.notification-message {
    color: #757575;
    font-size: 13px;
    line-height: 1.4;
}

.notification-close {
    background: none;
    border: none;
    color: #757575;
    cursor: pointer;
    padding: 4px;
    border-radius: 4px;
    transition: all 0.2s;
}

.notification-close:hover {
    background: rgba(0, 0, 0, 0.1);
    color: #212121;
}

.notification-time {
    text-align: left;
    color: #9E9E9E;
    font-size: 11px;
    margin-top: 8px;
    padding-right: 52px;
}

.notification-list {
    max-height: 400px;
    overflow-y: auto;
}

.notification-list-item {
    display: flex;
    gap: 12px;
    padding: 12px;
    border-bottom: 1px solid #EEEEEE;
    transition: background-color 0.2s;
}

.notification-list-item:hover {
    background: #FAFAFA;
}

.notification-list-item:last-child {
    border-bottom: none;
}

.notification-list-icon {
    width: 32px;
    height: 32px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 12px;
    color: white;
    flex-shrink: 0;
}

.notification-list-content {
    flex: 1;
}

.notification-list-title {
    font-weight: 600;
    color: #212121;
    margin-bottom: 2px;
    font-size: 13px;
}

.notification-list-message {
    color: #757575;
    font-size: 12px;
    line-height: 1.3;
    margin-bottom: 4px;
}

.notification-list-time {
    color: #9E9E9E;
    font-size: 11px;
}

@media (max-width: 480px) {
    .notification-container {
        right: 10px;
        left: 10px;
        max-width: none;
    }
    
    .notification {
        margin-bottom: 8px;
    }
}
`;

// Create global instance
window.NotificationSystem = NotificationSystem;

// Auto-initialize when DOM is ready
if (typeof window !== 'undefined') {
    document.addEventListener('DOMContentLoaded', () => {
        window.notificationSystem = new NotificationSystem();
        window.notificationSystem.initialize().catch(console.error);
    });
}

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = NotificationSystem;
}