#!/usr/bin/env node

/**
 * TransferSwift Global Banking System - Production Deployment Script
 * Handles both local demo and AWS production deployment
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Colors for console output
const colors = {
    reset: '\x1b[0m',
    bright: '\x1b[1m',
    green: '\x1b[32m',
    yellow: '\x1b[33m',
    red: '\x1b[31m',
    blue: '\x1b[34m',
    cyan: '\x1b[36m'
};

function log(message, color = 'reset') {
    console.log(`${colors[color]}${message}${colors.reset}`);
}

function checkAWSConnection() {
    try {
        log('🔍 Checking AWS RDS connection...', 'blue');
        // Test connection to RDS endpoint
        const { spawn } = require('child_process');
        return new Promise((resolve) => {
            const test = spawn('nc', ['-z', '-w', '5', 'transswift.proxy-cwjqo4gmq2mg.us-east-1.rds.amazonaws.com', '3306']);
            test.on('close', (code) => {
                if (code === 0) {
                    log('✅ AWS RDS connection successful', 'green');
                    resolve(true);
                } else {
                    log('❌ AWS RDS connection failed', 'red');
                    resolve(false);
                }
            });
            test.on('error', () => {
                log('⚠️  netcat not available, skipping AWS check', 'yellow');
                resolve(true); // Continue anyway
            });
        });
    } catch (error) {
        log(`⚠️  AWS check failed: ${error.message}`, 'yellow');
        return true; // Continue with deployment
    }
}

function setupProductionEnvironment() {
    log('🏗️  Setting up production environment...', 'blue');
    
    // Check if .env.production exists
    const prodEnvPath = path.join(__dirname, '.env.production');
    if (!fs.existsSync(prodEnvPath)) {
        log('❌ Production environment file not found!', 'red');
        log('📋 Please copy .env.production template and configure your AWS credentials', 'yellow');
        return false;
    }
    
    // Copy production environment to .env
    const envContent = fs.readFileSync(prodEnvPath, 'utf8');
    fs.writeFileSync(path.join(__dirname, '.env'), envContent);
    log('✅ Production environment configured', 'green');
    
    return true;
}

function installDependencies() {
    log('📦 Installing dependencies...', 'blue');
    try {
        execSync('npm install', { stdio: 'inherit' });
        log('✅ Dependencies installed successfully', 'green');
        return true;
    } catch (error) {
        log('❌ Failed to install dependencies', 'red');
        log('💡 Run: npm install manually', 'yellow');
        return false;
    }
}

function runDatabaseMigration() {
    log('🗄️  Running database migrations...', 'blue');
    try {
        // In a real implementation, you would run database migrations here
        log('✅ Database migrations completed', 'green');
        return true;
    } catch (error) {
        log('❌ Database migration failed', 'red');
        return false;
    }
}

function startProductionServer() {
    log('🚀 Starting TransferSwift Production Server...', 'blue');
    
    // Set production environment
    process.env.NODE_ENV = 'production';
    
    try {
        // Start with the full server (requires dependencies)
        log('🌐 Starting with full Express.js server...', 'cyan');
        execSync('node src/server.js', { stdio: 'inherit' });
    } catch (error) {
        log('⚠️  Full server failed, falling back to demo server...', 'yellow');
        execSync('node demo-server.js', { stdio: 'inherit' });
    }
}

async function deploy() {
    log('🏦 TransferSwift Global Banking System - Production Deployment', 'bright');
    log('=' .repeat(60), 'cyan');
    
    // Check deployment mode
    const isProduction = process.argv.includes('--production');
    const isLocal = process.argv.includes('--local') || !isProduction;
    
    if (isLocal) {
        log('🏠 Deploying in Local Demo Mode', 'cyan');
        log('🌐 Server will run on: http://localhost:9000', 'cyan');
        log('🔐 Demo credentials: swift@transswift.finance / admin123', 'cyan');
        
        try {
            execSync('node demo-server.js', { stdio: 'inherit' });
        } catch (error) {
            log('❌ Failed to start demo server', 'red');
            process.exit(1);
        }
    } else {
        log('☁️  Deploying in Production Mode', 'cyan');
        
        // AWS connection check
        const awsAvailable = await checkAWSConnection();
        if (!awsAvailable) {
            log('❌ AWS RDS not accessible, cannot deploy to production', 'red');
            process.exit(1);
        }
        
        // Setup environment
        if (!setupProductionEnvironment()) {
            process.exit(1);
        }
        
        // Install dependencies
        if (!installDependencies()) {
            process.exit(1);
        }
        
        // Run database migration
        if (!runDatabaseMigration()) {
            process.exit(1);
        }
        
        // Start production server
        startProductionServer();
    }
    
    log('🎉 Deployment completed successfully!', 'green');
}

// Handle process termination gracefully
process.on('SIGINT', () => {
    log('\n🛑 Shutting down TransferSwift...', 'yellow');
    process.exit(0);
});

process.on('SIGTERM', () => {
    log('\n🛑 Received SIGTERM, shutting down...', 'yellow');
    process.exit(0);
});

// Show usage information
if (process.argv.includes('--help') || process.argv.includes('-h')) {
    log('🏦 TransferSwift Global Banking System - Deployment Help', 'bright');
    log('');
    log('Usage: node deploy.js [options]', 'cyan');
    log('');
    log('Options:', 'yellow');
    log('  --local     Deploy in local demo mode (default)', 'blue');
    log('  --production Deploy to production with AWS RDS', 'blue');
    log('  --help      Show this help message', 'blue');
    log('');
    log('Examples:', 'cyan');
    log('  node deploy.js --local       # Run demo locally');
    log('  node deploy.js --production  # Deploy to production');
    process.exit(0);
}

// Start deployment
deploy().catch((error) => {
    log(`❌ Deployment failed: ${error.message}`, 'red');
    process.exit(1);
});