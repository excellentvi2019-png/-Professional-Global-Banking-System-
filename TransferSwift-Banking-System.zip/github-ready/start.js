#!/usr/bin/env node

/**
 * TransferSwift Global Banking System
 * Main Entry Point
 * Version 2.0.0
 */

const path = require('path');
const fs = require('fs');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const session = require('express-session');
const mongoose = require('mongoose');
const { createServer } = require('http');
const { Server } = require('socket.io');
const winston = require('winston');
require('dotenv').config();

// Create Express app
const app = express();
const server = createServer(app);

// Initialize Socket.IO
const io = new Server(server, {
    cors: {
        origin: process.env.CLIENT_URL || ["http://localhost:3000", "http://localhost:9000"],
        methods: ["GET", "POST"],
        credentials: true
    }
});

// =============================================
// Configuration
// =============================================

const CONFIG = {
    PORT: process.env.PORT || 9000,
    NODE_ENV: process.env.NODE_ENV || 'development',
    CLIENT_URL: process.env.CLIENT_URL || "http://localhost:3000",
    MONGODB_URI: process.env.MONGODB_URI || 'mongodb://localhost:27017/transswift-banking',
    JWT_SECRET: process.env.JWT_SECRET || 'transswift-jwt-secret-2025-super-secure',
    SESSION_SECRET: process.env.SESSION_SECRET || 'transswift-session-secret-2025',
    DEMO_MODE: process.env.DEMO_MODE === 'true',
    
    // Banking Settings
    DAILY_TRANSFER_LIMIT: 50000,
    MAX_TRANSFER_AMOUNT: 999999999,
    MIN_TRANSFER_AMOUNT: 0.01,
    
    // Security Settings
    MAX_LOGIN_ATTEMPTS: 5,
    LOCKOUT_TIME: 15 * 60 * 1000, // 15 minutes
    TOKEN_EXPIRY: 24 * 60 * 60 * 1000, // 24 hours
    
    // Notification Settings
    WEBSOCKET_PING_TIMEOUT: 30000,
    NOTIFICATION_RETENTION: 30 * 24 * 60 * 60 * 1000, // 30 days
};

// =============================================
// Logging Configuration
// =============================================

const logger = winston.createLogger({
    level: CONFIG.NODE_ENV === 'production' ? 'info' : 'debug',
    format: winston.format.combine(
        winston.format.timestamp({
            format: 'YYYY-MM-DD HH:mm:ss'
        }),
        winston.format.errors({ stack: true }),
        winston.format.json()
    ),
    defaultMeta: { 
        service: 'transswift-banking',
        environment: CONFIG.NODE_ENV,
        version: '2.0.0'
    },
    transports: [
        // Console transport
        new winston.transports.Console({
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.simple()
            )
        }),
        
        // File transport
        new winston.transports.File({
            filename: 'logs/error.log',
            level: 'error',
            maxsize: 5242880, // 5MB
            maxFiles: 5
        }),
        
        new winston.transports.File({
            filename: 'logs/combined.log',
            maxsize: 5242880, // 5MB
            maxFiles: 5
        })
    ]
});

// Add development transports
if (CONFIG.NODE_ENV !== 'production') {
    logger.add(new winston.transports.Console({
        level: 'debug',
        format: winston.format.combine(
            winston.format.colorize(),
            winston.format.printf(({ timestamp, level, message, ...meta }) => {
                let msg = `${timestamp} [${level}]: ${message}`;
                if (Object.keys(meta).length) {
                    msg += ` ${JSON.stringify(meta, null, 2)}`;
                }
                return msg;
            })
        )
    }));
}

// =============================================
// Security Middleware
// =============================================

// Helmet configuration
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            fontSrc: ["'self'", "https://fonts.gstatic.com"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'", "wss:", "ws:", CONFIG.CLIENT_URL],
            mediaSrc: ["'self'"],
            objectSrc: ["'none'"],
            frameAncestors: ["'none'"]
        }
    },
    crossOriginEmbedderPolicy: false,
    crossOriginOpenerPolicy: false,
    crossOriginResourcePolicy: false
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: CONFIG.NODE_ENV === 'production' ? 100 : 1000, // limit each IP
    message: {
        error: 'تم تجاوز حد الطلبات المسموح',
        retryAfter: '15 minutes'
    },
    standardHeaders: true,
    legacyHeaders: false,
});
app.use(limiter);

// Strict rate limiting for auth routes
const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // limit each IP to 5 requests per windowMs
    message: {
        error: 'تم تجاوز حد محاولات تسجيل الدخول',
        retryAfter: '15 minutes'
    },
    skipSuccessfulRequests: true
});

// =============================================
// General Middleware
// =============================================

app.use(cors({
    origin: CONFIG.NODE_ENV === 'production' 
        ? [CONFIG.CLIENT_URL]
        : [CONFIG.CLIENT_URL, `http://localhost:${CONFIG.PORT}`, 'http://localhost:3000'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With']
}));

app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Session configuration
app.use(session({
    secret: CONFIG.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: CONFIG.NODE_ENV === 'production',
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
        httpOnly: true,
        sameSite: CONFIG.NODE_ENV === 'production' ? 'strict' : 'lax'
    },
    name: 'transswift.sid',
    rolling: true
}));

// Request logging
if (CONFIG.NODE_ENV !== 'production') {
    app.use((req, res, next) => {
        const start = Date.now();
        res.on('finish', () => {
            const duration = Date.now() - start;
            logger.info(`${req.method} ${req.path} ${res.statusCode} ${duration}ms`);
        });
        next();
    });
}

// =============================================
// Static Files
// =============================================

app.use('/assets', express.static(path.join(__dirname, 'public', 'assets'), {
    maxAge: '1d',
    etag: true,
    lastModified: true
}));

// Serve static files
app.use(express.static(path.join(__dirname, 'public'), {
    maxAge: '1h',
    etag: true,
    lastModified: true
}));

// =============================================
// Database Connection
// =============================================

const connectDB = async () => {
    try {
        const options = {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            maxPoolSize: 10,
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
            family: 4 // Use IPv4
        };

        const conn = await mongoose.connect(CONFIG.MONGODB_URI, options);
        logger.info(`MongoDB Connected: ${conn.connection.host}`);
        
        // Handle connection events
        mongoose.connection.on('error', (err) => {
            logger.error('MongoDB connection error:', err);
        });
        
        mongoose.connection.on('disconnected', () => {
            logger.warn('MongoDB disconnected');
        });
        
        mongoose.connection.on('reconnected', () => {
            logger.info('MongoDB reconnected');
        });
        
    } catch (error) {
        logger.error('Database connection error:', error);
        
        if (CONFIG.DEMO_MODE) {
            logger.warn('Running in demo mode without database');
            return;
        }
        
        process.exit(1);
    }
};

// =============================================
// Models and Routes
// =============================================

// Load models
const User = require('./src/models/User');
const Account = require('./src/models/Account');
const Transfer = require('./src/models/Transfer');

// Load route modules
const authRoutes = require('./src/routes/auth');
const userRoutes = require('./src/routes/users');
const accountRoutes = require('./src/routes/accounts');
const transferRoutes = require('./src/routes/transfers');
const notificationRoutes = require('./src/routes/notifications');
const adminRoutes = require('./src/routes/admin');
const apiRoutes = require('./src/routes/api');
const webhookRoutes = require('./src/routes/webhooks');

// Apply rate limiting to auth routes
app.use('/api/auth', authLimiter, authRoutes);

// Mount other routes
app.use('/api/users', userRoutes);
app.use('/api/accounts', accountRoutes);
app.use('/api/transfers', transferRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', apiRoutes);
app.use('/webhooks', webhookRoutes);

// =============================================
// Socket.IO Setup
// =============================================

// Connected users tracking
const connectedUsers = new Map();

// Socket middleware
io.use(async (socket, next) => {
    try {
        const token = socket.handshake.auth.token;
        if (!token) {
            return next(new Error('Authentication token required'));
        }
        
        // Verify JWT token (simplified for demo)
        const jwt = require('jsonwebtoken');
        const decoded = jwt.verify(token, CONFIG.JWT_SECRET);
        socket.userId = decoded.userId;
        
        next();
    } catch (error) {
        next(new Error('Invalid authentication token'));
    }
});

io.on('connection', (socket) => {
    logger.info(`User connected: ${socket.userId} (${socket.id})`);
    
    // Track connected user
    connectedUsers.set(socket.userId, socket.id);
    
    // Join user-specific room
    socket.join(`user_${socket.userId}`);
    
    // Handle authentication events
    socket.on('authenticate', (token) => {
        try {
            const jwt = require('jsonwebtoken');
            const decoded = jwt.verify(token, CONFIG.JWT_SECRET);
            socket.userId = decoded.userId;
            socket.emit('authenticated', { status: 'success' });
            logger.info(`Socket authenticated: ${socket.userId}`);
        } catch (error) {
            socket.emit('authentication_error', { error: 'Invalid token' });
        }
    });
    
    // Handle room subscriptions
    socket.on('subscribe', (data) => {
        switch (data.type) {
            case 'balance':
                socket.join(`balance_${socket.userId}`);
                break;
            case 'transfers':
                socket.join(`transfers_${socket.userId}`);
                break;
            case 'notifications':
                socket.join(`notifications_${socket.userId}`);
                break;
            case 'transfer':
                if (data.transferId) {
                    socket.join(`transfer_${data.transferId}`);
                }
                break;
        }
    });
    
    socket.on('unsubscribe', (data) => {
        switch (data.type) {
            case 'balance':
                socket.leave(`balance_${socket.userId}`);
                break;
            case 'transfers':
                socket.leave(`transfers_${socket.userId}`);
                break;
            case 'notifications':
                socket.leave(`notifications_${socket.userId}`);
                break;
            case 'transfer':
                if (data.transferId) {
                    socket.leave(`transfer_${data.transferId}`);
                }
                break;
        }
    });
    
    socket.on('disconnect', () => {
        logger.info(`User disconnected: ${socket.userId} (${socket.id})`);
        connectedUsers.delete(socket.userId);
    });
});

// =============================================
// Broadcast Functions
// =============================================

// Real-time transfer updates
const broadcastTransferUpdate = (transferId, data) => {
    io.to(`transfer_${transferId}`).emit('transfer_update', data);
    io.to(`transfers_${data.senderId}`).emit('transfer_update', data);
    if (data.receiverId) {
        io.to(`transfers_${data.receiverId}`).emit('transfer_update', data);
    }
};

// Real-time balance updates
const broadcastBalanceUpdate = (userId, data) => {
    io.to(`balance_${userId}`).emit('balance_update', data);
};

// Real-time notifications
const broadcastNotification = (userId, notification) => {
    io.to(`user_${userId}`).emit('notification', notification);
    io.to(`notifications_${userId}`).emit('notification', notification);
};

// Security alerts
const broadcastSecurityAlert = (userId, alert) => {
    io.to(`user_${userId}`).emit('security_alert', alert);
    io.to('security_alerts').emit('security_alert', alert);
};

// System notifications
const broadcastSystemNotification = (notification) => {
    io.emit('system_notification', notification);
};

// Make broadcast functions globally available
global.broadcastFunctions = {
    transferUpdate: broadcastTransferUpdate,
    balanceUpdate: broadcastBalanceUpdate,
    notification: broadcastNotification,
    securityAlert: broadcastSecurityAlert,
    systemNotification: broadcastSystemNotification
};

// =============================================
// Routes
// =============================================

// Health check endpoint
app.get('/health', (req, res) => {
    const health = {
        status: 'OK',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        version: '2.0.0',
        environment: CONFIG.NODE_ENV,
        database: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected',
        demoMode: CONFIG.DEMO_MODE,
        connectedUsers: connectedUsers.size
    };
    
    res.status(200).json(health);
});

// Demo mode health check
app.get('/demo/health', (req, res) => {
    res.json({
        status: 'Demo Mode Active',
        timestamp: new Date().toISOString(),
        version: '2.0.0-demo',
        demoMode: true,
        features: {
            authentication: true,
            accounts: true,
            transfers: true,
            notifications: true,
            realTimeUpdates: true
        }
    });
});

// API documentation
app.get('/api/docs', (req, res) => {
    res.json({
        title: 'TransferSwift Banking API',
        version: '2.0.0',
        endpoints: {
            authentication: '/api/auth',
            users: '/api/users',
            accounts: '/api/accounts',
            transfers: '/api/transfers',
            notifications: '/api/notifications',
            admin: '/api/admin'
        },
        documentation: 'https://docs.transswift.finance'
    });
});

// =============================================
// Error Handling
// =============================================

// 404 handler
app.use('*', (req, res) => {
    res.status(404).json({
        error: 'المسار المطلوب غير موجود',
        path: req.originalUrl,
        method: req.method,
        timestamp: new Date().toISOString()
    });
});

// Global error handler
app.use((err, req, res, next) => {
    const errorId = require('crypto').randomBytes(8).toString('hex');
    
    logger.error(`Error ${errorId}:`, {
        error: err.message,
        stack: err.stack,
        url: req.url,
        method: req.method,
        ip: req.ip,
        userAgent: req.get('User-Agent'),
        userId: req.user?.userId
    });
    
    res.status(err.status || 500).json({
        error: CONFIG.NODE_ENV === 'production' 
            ? 'حدث خطأ داخلي في الخادم' 
            : err.message,
        errorId,
        timestamp: new Date().toISOString(),
        requestId: req.headers['x-request-id'] || 'unknown'
    });
});

// =============================================
// Startup
// =============================================

async function startServer() {
    try {
        // Ensure logs directory exists
        if (!fs.existsSync('logs')) {
            fs.mkdirSync('logs');
        }
        
        // Connect to database
        if (!CONFIG.DEMO_MODE) {
            await connectDB();
        } else {
            logger.warn('Starting in demo mode without database');
        }
        
        // Start server
        server.listen(CONFIG.PORT, () => {
            logger.info(`
🏦 TransferSwift Global Banking System v2.0.0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🌐 Server running on port ${CONFIG.PORT}
🔗 Health check: http://localhost:${CONFIG.PORT}/health
📚 Demo health: http://localhost:${CONFIG.PORT}/demo/health
📖 API docs: http://localhost:${CONFIG.PORT}/api/docs
📊 Socket.IO enabled for real-time updates
💾 Database: ${CONFIG.DEMO_MODE ? 'Demo Mode (No DB)' : 'MongoDB'}
🔒 Environment: ${CONFIG.NODE_ENV}
👥 Connected Users: 0
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
🚀 Ready for global banking operations!
            `);
        });
        
    } catch (error) {
        logger.error('Failed to start server:', error);
        process.exit(1);
    }
}

// Handle uncaught exceptions
process.on('uncaughtException', (err) => {
    logger.error('Uncaught Exception:', err);
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
    process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    logger.info('SIGTERM received, shutting down gracefully');
    server.close(() => {
        if (!CONFIG.DEMO_MODE) {
            mongoose.connection.close();
        }
        logger.info('Server closed');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    logger.info('SIGINT received, shutting down gracefully');
    server.close(() => {
        if (!CONFIG.DEMO_MODE) {
            mongoose.connection.close();
        }
        logger.info('Server closed');
        process.exit(0);
    });
});

// Start the server
startServer();

module.exports = { app, server, io, CONFIG };