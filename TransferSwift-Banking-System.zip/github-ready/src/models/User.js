const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const UserSchema = new mongoose.Schema({
    // Basic Information
    userId: {
        type: String,
        unique: true,
        required: true,
        index: true
    },
    email: {
        type: String,
        required: true,
        unique: true,
        lowercase: true,
        index: true
    },
    password: {
        type: String,
        required: true,
        minlength: 8
    },
    phone: {
        type: String,
        required: true
    },
    firstName: {
        type: String,
        required: true
    },
    lastName: {
        type: String,
        required: true
    },
    dateOfBirth: {
        type: Date,
        required: true
    },
    nationality: {
        type: String,
        required: true
    },
    
    // Address Information
    address: {
        street: String,
        city: String,
        state: String,
        postalCode: String,
        country: String
    },
    
    // Banking Information
    kycStatus: {
        type: String,
        enum: ['pending', 'in_review', 'approved', 'rejected'],
        default: 'pending'
    },
    kycDocuments: [{
        type: String,
        url: String,
        uploadedAt: Date,
        verifiedAt: Date
    }],
    
    // Account Status
    status: {
        type: String,
        enum: ['active', 'inactive', 'suspended', 'closed'],
        default: 'inactive'
    },
    accountTier: {
        type: String,
        enum: ['basic', 'standard', 'premium', 'enterprise'],
        default: 'basic'
    },
    
    // Security
    twoFactorEnabled: {
        type: Boolean,
        default: false
    },
    twoFactorSecret: String,
    failedLoginAttempts: {
        type: Number,
        default: 0
    },
    lastLoginAt: Date,
    lastLoginIP: String,
    sessionTokens: [{
        token: String,
        createdAt: Date,
        expiresAt: Date,
        ipAddress: String,
        userAgent: String
    }],
    
    // Preferences
    preferredLanguage: {
        type: String,
        default: 'ar'
    },
    preferredCurrency: {
        type: String,
        default: 'USD'
    },
    timezone: {
        type: String,
        default: 'Asia/Riyadh'
    },
    notifications: {
        email: {
            type: Boolean,
            default: true
        },
        sms: {
            type: Boolean,
            default: true
        },
        push: {
            type: Boolean,
            default: true
        }
    },
    
    // Risk Management
    riskScore: {
        type: Number,
        min: 0,
        max: 100,
        default: 0
    },
    riskLevel: {
        type: String,
        enum: ['low', 'medium', 'high', 'critical'],
        default: 'low'
    },
    
    // System Fields
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    },
    lastActivity: Date
});

// Indexes for performance
UserSchema.index({ email: 1 });
UserSchema.index({ userId: 1 });
UserSchema.index({ kycStatus: 1 });
UserSchema.index({ status: 1 });

// Pre-save middleware to hash password
UserSchema.pre('save', async function(next) {
    if (!this.isModified('password')) return next();
    
    try {
        const salt = await bcrypt.genSalt(12);
        this.password = await bcrypt.hash(this.password, salt);
        this.updatedAt = new Date();
        next();
    } catch (error) {
        next(error);
    }
});

// Method to compare password
UserSchema.methods.comparePassword = async function(candidatePassword) {
    return await bcrypt.compare(candidatePassword, this.password);
};

// Method to generate user ID
UserSchema.statics.generateUserId = function() {
    return `TS${Date.now()}${Math.random().toString(36).substr(2, 5).toUpperCase()}`;
};

// Method to get full name
UserSchema.virtual('fullName').get(function() {
    return `${this.firstName} ${this.lastName}`;
});

// Method to check if account is verified
UserSchema.methods.isVerified = function() {
    return this.kycStatus === 'approved' && this.status === 'active';
};

// Method to increment failed login attempts
UserSchema.methods.incrementFailedAttempts = function() {
    this.failedLoginAttempts += 1;
    if (this.failedLoginAttempts >= 5) {
        this.status = 'suspended';
    }
    return this.save();
};

// Method to reset failed attempts
UserSchema.methods.resetFailedAttempts = function() {
    this.failedLoginAttempts = 0;
    this.lastLoginAt = new Date();
    return this.save();
};

// Method to add session token
UserSchema.methods.addSessionToken = function(token, ipAddress, userAgent) {
    const sessionToken = {
        token: crypto.createHash('sha256').update(token).digest('hex'),
        createdAt: new Date(),
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
        ipAddress,
        userAgent
    };
    
    // Remove old tokens
    this.sessionTokens = this.sessionTokens.filter(t => t.expiresAt > new Date());
    this.sessionTokens.push(sessionToken);
    
    return this.save();
};

// Method to remove session token
UserSchema.methods.removeSessionToken = function(token) {
    const hashedToken = crypto.createHash('sha256').update(token).digest('hex');
    this.sessionTokens = this.sessionTokens.filter(t => t.token !== hashedToken);
    return this.save();
};

module.exports = mongoose.model('User', UserSchema);