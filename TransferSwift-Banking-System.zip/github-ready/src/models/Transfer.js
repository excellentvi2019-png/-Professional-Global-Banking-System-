const mongoose = require('mongoose');
const crypto = require('crypto');

const TransferSchema = new mongoose.Schema({
    // Transaction Identification
    transactionId: {
        type: String,
        unique: true,
        required: true,
        index: true
    },
    referenceId: {
        type: String,
        sparse: true,
        unique: true,
        index: true
    },
    swiftReference: {
        type: String,
        sparse: true,
        unique: true
    },
    externalReference: String,
    
    // Parties Involved
    senderId: {
        type: String,
        required: true,
        ref: 'User',
        index: true
    },
    senderAccountId: {
        type: String,
        required: true,
        ref: 'Account',
        index: true
    },
    
    receiverId: {
        type: String,
        required: true,
        ref: 'User'
    },
    receiverAccountId: {
        type: String,
        required: true,
        ref: 'Account'
    },
    
    // Transfer Details
    transferType: {
        type: String,
        enum: ['domestic', 'international', 'swift', 'sepa', 'ach', 'crypto', 'instant'],
        required: true
    },
    
    // Payment Information
    amount: {
        type: Number,
        required: true,
        min: 0.01,
        max: 999999999
    },
    currency: {
        type: String,
        required: true,
        enum: ['USD', 'EUR', 'GBP', 'SAR', 'AED', 'KWD', 'BHD', 'QAR', 'JOD', 'EGP', 'SYP', 'LBP', 'CAD', 'AUD', 'CHF', 'JPY', 'CNY', 'INR', 'BTC', 'ETH', 'USDT']
    },
    originalAmount: {
        type: Number,
        required: true
    },
    originalCurrency: String,
    exchangeRate: {
        type: Number,
        default: 1.0
    },
    
    // Fees and Costs
    fee: {
        amount: {
            type: Number,
            default: 0,
            min: 0
        },
        currency: {
            type: String,
            default: function() {
                return this.currency;
            }
        },
        breakdown: [{
            type: String, // processing, international, intermediary, correspondent
            amount: Number,
            currency: String,
            description: String
        }]
    },
    totalAmount: {
        type: Number,
        required: true
    },
    
    // Recipient Information
    recipientDetails: {
        name: {
            type: String,
            required: true
        },
        bankName: {
            type: String,
            required: true
        },
        accountNumber: {
            type: String,
            required: true
        },
        iban: String,
        swiftCode: {
            type: String,
            required: true
        },
        address: {
            street: String,
            city: String,
            country: String,
            postalCode: String
        },
        contact: {
            email: String,
            phone: String
        },
        purpose: {
            type: String,
            enum: ['gift', 'remittance', 'payment', 'investment', 'salary', 'fee', 'refund', 'other'],
            default: 'payment'
        }
    },
    
    // Transfer Details
    description: {
        type: String,
        maxlength: 140
    },
    instructions: String,
    
    // Status Management
    status: {
        type: String,
        enum: [
            'pending',           // تم إنشاء التحويل ولكن لم يتم تأكيده
            'authorized',        // تم التأكيد من المرسل
            'processing',        // قيد المعالجة
            'verified',          // تم التحقق من البيانات
            'awaiting_review',   // في انتظار المراجعة
            'approved',          // تمت الموافقة عليه
            'sent_to_bank',      // تم الإرسال للبنك
            'processing_bank',   // قيد المعالجة في البنك
            'sent_to_recipient', // تم الإرسال للمستلم
            'delivered',         // تم التسليم
            'failed',            // فشل
            'cancelled',         // ملغي
            'refunded',          // مُسترد
            'on_hold'            // محجوز
        ],
        default: 'pending',
        index: true
    },
    
    // Status History
    statusHistory: [{
        status: {
            type: String,
            required: true
        },
        timestamp: {
            type: Date,
            default: Date.now
        },
        notes: String,
        userId: String // المستخدم الذي غير الحالة
    }],
    
    // Security and Compliance
    complianceChecks: {
        amlPassed: Boolean,
        sanctionsPassed: Boolean,
        riskScore: {
            type: Number,
            min: 0,
            max: 100
        },
        flagged: {
            type: Boolean,
            default: false
        },
        flaggedReasons: [String],
        manualReviewRequired: Boolean
    },
    
    // Two-Factor Authentication
    authentication: {
        required: {
            type: Boolean,
            default: false
        },
        completed: {
            type: Boolean,
            default: false
        },
        method: {
            type: String,
            enum: ['sms', 'email', 'app', 'biometric']
        },
        code: String,
        verifiedAt: Date,
        attempts: {
            type: Number,
            default: 0
        }
    },
    
    // Document Requirements
    documents: [{
        type: String,
        url: String,
        uploadedAt: Date,
        verifiedAt: Date
    }],
    
    // Timing Information
    requestedAt: {
        type: Date,
        default: Date.now
    },
    scheduledFor: Date,
    processedAt: Date,
    completedAt: Date,
    expiresAt: Date,
    
    // Communication
    notifications: [{
        type: {
            type: String,
            enum: ['email', 'sms', 'push', 'in_app']
        },
        sent: {
            type: Boolean,
            default: false
        },
        sentAt: Date,
        messageId: String,
        status: String
    }],
    
    // Error Information
    errors: [{
        code: String,
        message: String,
        timestamp: {
            type: Date,
            default: Date.now
        },
        resolved: {
            type: Boolean,
            default: false
        }
    }],
    
    // Settlement Information
    settlement: {
        method: {
            type: String,
            enum: ['real_time', 'batch', 'next_day', 't_plus_1', 't_plus_2']
        },
        batchId: String,
        settlementDate: Date,
        confirmationNumber: String
    },
    
    // Tracking
    tracking: [{
        location: String,
        timestamp: {
            type: Date,
            default: Date.now
        },
        status: String,
        description: String
    }],
    
    // System Fields
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

// Indexes for performance
TransferSchema.index({ transactionId: 1 });
TransferSchema.index({ referenceId: 1 });
TransferSchema.index({ swiftReference: 1 });
TransferSchema.index({ senderId: 1 });
TransferSchema.index({ receiverId: 1 });
TransferSchema.index({ status: 1 });
TransferSchema.index({ transferType: 1 });
TransferSchema.index({ currency: 1 });
TransferSchema.index({ requestedAt: 1 });
TransferSchema.index({ amount: 1 });

// Pre-save middleware
TransferSchema.pre('save', function(next) {
    this.updatedAt = new Date();
    
    // Calculate total amount
    this.totalAmount = this.amount + this.fee.amount;
    
    // Generate reference ID if not exists
    if (!this.referenceId) {
        this.referenceId = this.generateReferenceId();
    }
    
    next();
});

// Method to generate transaction ID
TransferSchema.statics.generateTransactionId = function() {
    return `TX${Date.now()}${Math.random().toString(36).substr(2, 6).toUpperCase()}`;
};

// Method to generate reference ID
TransferSchema.methods.generateReferenceId = function() {
    const timestamp = Date.now().toString();
    const random = Math.random().toString(36).substr(2, 8).toUpperCase();
    return `REF${timestamp.slice(-8)}${random}`;
};

// Method to generate SWIFT reference
TransferSchema.statics.generateSWIFTReference = function() {
    return `SWIFT${Date.now()}${Math.random().toString(36).substr(2, 8).toUpperCase()}`;
};

// Method to update status
TransferSchema.methods.updateStatus = function(newStatus, notes = '', userId = null) {
    this.status = newStatus;
    this.statusHistory.push({
        status: newStatus,
        timestamp: new Date(),
        notes: notes,
        userId: userId
    });
    
    // Set timestamp based on status
    if (newStatus === 'completed' || newStatus === 'delivered') {
        this.completedAt = new Date();
    } else if (newStatus === 'processing' || newStatus === 'approved') {
        this.processedAt = new Date();
    }
    
    return this.save();
};

// Method to add compliance check result
TransferSchema.methods.addComplianceCheck = function(check, passed, reason = '') {
    if (!this.complianceChecks) {
        this.complianceChecks = {};
    }
    
    this.complianceChecks[check] = passed;
    
    if (!passed && reason) {
        this.complianceChecks.flagged = true;
        if (!this.complianceChecks.flaggedReasons) {
            this.complianceChecks.flaggedReasons = [];
        }
        this.complianceChecks.flaggedReasons.push(reason);
    }
    
    return this.save();
};

// Method to calculate fee
TransferSchema.methods.calculateFee = function() {
    const baseRate = this.transferType === 'domestic' ? 0.005 : // 0.5% domestic
                   this.transferType === 'international' ? 0.015 : // 1.5% international
                   this.transferType === 'crypto' ? 0.01 : // 1% crypto
                   this.transferType === 'instant' ? 0.02 : // 2% instant
                   0.012; // default
    
    const minFee = 1.0; // $1 minimum
    const maxFee = 100.0; // $100 maximum
    
    let fee = Math.max(this.amount * baseRate, minFee);
    fee = Math.min(fee, maxFee);
    
    this.fee.amount = fee;
    this.fee.currency = this.currency;
    
    return fee;
};

// Method to add tracking entry
TransferSchema.methods.addTrackingEntry = function(location, status, description) {
    this.tracking.push({
        location: location,
        timestamp: new Date(),
        status: status,
        description: description
    });
    
    return this.save();
};

// Method to check if transfer is completed
TransferSchema.methods.isCompleted = function() {
    return ['completed', 'delivered'].includes(this.status);
};

// Method to check if transfer failed
TransferSchema.methods.hasFailed = function() {
    return ['failed', 'cancelled'].includes(this.status);
};

// Method to add error
TransferSchema.methods.addError = function(code, message) {
    this.errors.push({
        code: code,
        message: message,
        timestamp: new Date(),
        resolved: false
    });
    
    return this.save();
};

// Virtual for transaction summary
TransferSchema.virtual('summary').get(function() {
    return {
        id: this.transactionId,
        reference: this.referenceId,
        amount: this.amount,
        currency: this.currency,
        fee: this.fee.amount,
        total: this.totalAmount,
        type: this.transferType,
        status: this.status,
        from: this.senderId,
        to: this.receiverId,
        date: this.requestedAt
    };
});

module.exports = mongoose.model('Transfer', TransferSchema);