const mongoose = require('mongoose');

const AccountSchema = new mongoose.Schema({
    // Account Identification
    accountId: {
        type: String,
        unique: true,
        required: true,
        index: true
    },
    userId: {
        type: String,
        required: true,
        ref: 'User',
        index: true
    },
    
    // Account Details
    accountNumber: {
        type: String,
        required: true,
        unique: true,
        index: true
    },
    iban: {
        type: String,
        sparse: true,
        index: true
    },
    swiftCode: {
        type: String,
        sparse: true
    },
    
    // Bank Information
    bankName: {
        type: String,
        required: true
    },
    bankCode: String,
    branchCode: String,
    branchName: String,
    country: {
        type: String,
        required: true
    },
    
    // Account Properties
    accountType: {
        type: String,
        enum: ['current', 'savings', 'business', 'corporate', 'investment'],
        required: true
    },
    currency: {
        type: String,
        required: true,
        enum: ['USD', 'EUR', 'GBP', 'SAR', 'AED', 'KWD', 'BHD', 'QAR', 'JOD', 'EGP', 'SYP', 'LBP', 'CAD', 'AUD', 'CHF', 'JPY', 'CNY', 'INR', 'BTC', 'ETH', 'USDT']
    },
    
    // Balance Information
    balance: {
        type: Number,
        required: true,
        default: 0,
        min: 0
    },
    availableBalance: {
        type: Number,
        required: true,
        default: 0,
        min: 0
    },
    reservedAmount: {
        type: Number,
        default: 0,
        min: 0
    },
    
    // Account Limits
    dailyWithdrawalLimit: {
        type: Number,
        default: 10000
    },
    dailyTransferLimit: {
        type: Number,
        default: 50000
    },
    monthlyLimit: {
        type: Number,
        default: 500000
    },
    
    // Account Status
    status: {
        type: String,
        enum: ['active', 'inactive', 'frozen', 'closed', 'under_review'],
        default: 'inactive'
    },
    
    // Interest and Fees
    interestRate: {
        type: Number,
        default: 0,
        min: 0
    },
    maintenanceFee: {
        type: Number,
        default: 0
    },
    
    // Timestamps
    openedAt: {
        type: Date,
        default: Date.now
    },
    lastActivity: Date,
    
    // System Fields
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
});

// Indexes for performance
AccountSchema.index({ accountNumber: 1 });
AccountSchema.index({ userId: 1 });
AccountSchema.index({ accountId: 1 });
AccountSchema.index({ iban: 1 });
AccountSchema.index({ status: 1 });
AccountSchema.index({ currency: 1 });

// Virtual for balance information
AccountSchema.virtual('balanceInfo').get(function() {
    return {
        total: this.balance,
        available: this.availableBalance,
        reserved: this.reservedAmount,
        currency: this.currency
    };
});

// Method to generate account number
AccountSchema.statics.generateAccountNumber = function() {
    const timestamp = Date.now().toString();
    const random = Math.floor(Math.random() * 1000000).toString().padStart(6, '0');
    return (timestamp + random).slice(-16);
};

// Method to generate IBAN
AccountSchema.statics.generateIBAN = function(countryCode = 'SA') {
    const countryCodes = {
        'SA': 'SA03',
        'AE': 'AE07',
        'KW': 'KW03',
        'BH': 'BH02',
        'QA': 'QA03',
        'JO': 'JO94'
    };
    
    const code = countryCodes[countryCode] || 'SA03';
    const accountNumber = this.generateAccountNumber().slice(-10);
    const checkDigits = Math.floor(Math.random() * 100).toString().padStart(2, '0');
    
    return `${code}${checkDigits}${accountNumber}`;
};

// Method to generate SWIFT code
AccountSchema.statics.generateSWIFTCode = function(bankCode = 'TS') {
    return `${bankCode}${countryCode || 'SA'}XXX`;
};

// Method to update balance
AccountSchema.methods.updateBalance = function(amount, type = 'transfer') {
    if (type === 'credit') {
        this.balance += amount;
        this.availableBalance += amount;
    } else if (type === 'debit') {
        if (this.availableBalance < amount) {
            throw new Error('رصيد غير كافي');
        }
        this.balance -= amount;
        this.availableBalance -= amount;
    }
    
    this.lastActivity = new Date();
    this.updatedAt = new Date();
    
    return this.save();
};

// Method to reserve amount
AccountSchema.methods.reserveAmount = function(amount) {
    if (this.availableBalance < amount) {
        throw new Error('رصيد متاح غير كافي للحجز');
    }
    
    this.availableBalance -= amount;
    this.reservedAmount += amount;
    
    return this.save();
};

// Method to release reserved amount
AccountSchema.methods.releaseReservedAmount = function(amount) {
    if (this.reservedAmount < amount) {
        throw new Error('مبلغ محجوز غير كافي للإفراج عنه');
    }
    
    this.reservedAmount -= amount;
    this.availableBalance += amount;
    
    return this.save();
};

// Method to check daily limits
AccountSchema.methods.checkDailyLimit = function(amount, type = 'transfer') {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    // This would need to be implemented with transaction history
    // For now, we'll assume the check passes
    const limit = type === 'withdrawal' ? this.dailyWithdrawalLimit : this.dailyTransferLimit;
    
    return amount <= limit;
};

// Method to freeze account
AccountSchema.methods.freeze = function(reason = 'Administrative freeze') {
    this.status = 'frozen';
    this.updatedAt = new Date();
    
    return this.save();
};

// Method to unfreeze account
AccountSchema.methods.unfreeze = function() {
    this.status = 'active';
    this.updatedAt = new Date();
    
    return this.save();
};

// Method to close account
AccountSchema.methods.close = function() {
    if (this.balance > 0) {
        throw new Error('لا يمكن إغلاق حساب يحتوي على رصيد');
    }
    
    this.status = 'closed';
    this.updatedAt = new Date();
    
    return this.save();
};

module.exports = mongoose.model('Account', AccountSchema);