/**
 * TransferSwift Global Banking System
 * Enterprise-Level Banking Platform
 * Version 2.0.0
 */

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const session = require('express-session');
const mongoose = require('mongoose');
const { createServer } = require('http');
const { Server } = require('socket.io');
const winston = require('winston');
const dailyRotateFile = require('winston-daily-rotate-file');
const path = require('path');
require('dotenv').config();

// Initialize Express App
const app = express();
const server = createServer(app);

// Initialize Socket.IO
const io = new Server(server, {
    cors: {
        origin: process.env.CLIENT_URL || "http://localhost:3000",
        methods: ["GET", "POST"],
        credentials: true
    }
});

// Logger Configuration
const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.errors({ stack: true }),
        winston.format.json()
    ),
    defaultMeta: { service: 'transswift-banking' },
    transports: [
        new winston.transports.Console({
            format: winston.format.simple()
        }),
        new dailyRotateFile({
            filename: 'logs/application-%DATE%.log',
            datePattern: 'YYYY-MM-DD',
            zippedArchive: true,
            maxSize: '20m',
            maxFiles: '14d',
            dirname: path.join(__dirname, 'logs')
        })
    ]
});

// Security Middleware
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            fontSrc: ["'self'", "https://fonts.gstatic.com"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'", "wss:", "ws:"]
        }
    }
}));

// Rate Limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // limit each IP to 100 requests per windowMs
    message: 'تم تجاوز الحد المسموح من الطلبات، يرجى المحاولة لاحقاً'
});
app.use(limiter);

// General Middleware
app.use(cors({
    origin: process.env.CLIENT_URL || "http://localhost:3000",
    credentials: true
}));
app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Session Configuration
app.use(session({
    secret: process.env.SESSION_SECRET || 'transswift-secret-key-2025',
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: process.env.NODE_ENV === 'production',
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
}));

// Database Connection
const connectDB = async () => {
    try {
        const conn = await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/transswift-banking');
        logger.info(`MongoDB Connected: ${conn.connection.host}`);
    } catch (error) {
        logger.error('Database connection error:', error);
        process.exit(1);
    }
};

// Import Route Modules
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/users');
const accountRoutes = require('./routes/accounts');
const transferRoutes = require('./routes/transfers');
const notificationRoutes = require('./routes/notifications');
const adminRoutes = require('./routes/admin');
const apiRoutes = require('./routes/api');
const webhookRoutes = require('./routes/webhooks');

// Mount Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);
app.use('/api/accounts', accountRoutes);
app.use('/api/transfers', transferRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api', apiRoutes);
app.use('/webhooks', webhookRoutes);

// Health Check Endpoint
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        uptime: process.uptime(),
        memory: process.memoryUsage(),
        version: '2.0.0',
        environment: process.env.NODE_ENV || 'development'
    });
});

// Error Handling Middleware
app.use((err, req, res, next) => {
    logger.error('Unhandled Error:', {
        error: err.message,
        stack: err.stack,
        url: req.url,
        method: req.method,
        ip: req.ip,
        userAgent: req.get('User-Agent')
    });
    
    res.status(500).json({
        error: 'حدث خطأ داخلي في الخادم',
        timestamp: new Date().toISOString(),
        requestId: req.headers['x-request-id']
    });
});

// 404 Handler
app.use('*', (req, res) => {
    res.status(404).json({
        error: 'المسار المطلوب غير موجود',
        path: req.originalUrl
    });
});

// Socket.IO Connection Handling
io.on('connection', (socket) => {
    logger.info(`User connected: ${socket.id}`);
    
    // Authentication check for sockets
    socket.on('authenticate', (token) => {
        // Verify JWT token here
        socket.userId = token;
        socket.join(`user_${token}`);
        socket.emit('authenticated', { status: 'success' });
    });
    
    // Join transfer room for real-time updates
    socket.on('join_transfer_room', (transferId) => {
        socket.join(`transfer_${transferId}`);
    });
    
    // Real-time balance updates
    socket.on('subscribe_balance', (userId) => {
        socket.join(`balance_${userId}`);
    });
    
    socket.on('disconnect', () => {
        logger.info(`User disconnected: ${socket.id}`);
    });
});

// Broadcast functions for real-time updates
const broadcastTransferUpdate = (transferId, data) => {
    io.to(`transfer_${transferId}`).emit('transfer_update', data);
};

const broadcastBalanceUpdate = (userId, data) => {
    io.to(`balance_${userId}`).emit('balance_update', data);
};

const broadcastNotification = (userId, notification) => {
    io.to(`user_${userId}`).emit('notification', notification);
};

// Global object for broadcasting
global.broadcastFunctions = {
    transferUpdate: broadcastTransferUpdate,
    balanceUpdate: broadcastBalanceUpdate,
    notification: broadcastNotification
};

// Start Server
const PORT = process.env.PORT || 9000;

server.listen(PORT, async () => {
    await connectDB();
    logger.info(`🏦 TransferSwift Banking System v2.0.0`);
    logger.info(`🌐 Server running on port ${PORT}`);
    logger.info(`🔗 Health check: http://localhost:${PORT}/health`);
    logger.info(`📊 Socket.IO enabled for real-time updates`);
    logger.info(`🚀 Ready for global banking operations!`);
});

// Graceful Shutdown
process.on('SIGTERM', () => {
    logger.info('SIGTERM received, shutting down gracefully');
    server.close(() => {
        mongoose.connection.close();
        logger.info('Server closed');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    logger.info('SIGINT received, shutting down gracefully');
    server.close(() => {
        mongoose.connection.close();
        logger.info('Server closed');
        process.exit(0);
    });
});

module.exports = app;