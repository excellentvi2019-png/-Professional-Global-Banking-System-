const express = require('express');
const { body, validationResult } = require('express-validator');
const Transfer = require('../models/Transfer');
const Account = require('../models/Account');
const User = require('../models/User');
const { authenticateToken } = require('./auth');
const axios = require('axios');

const router = express.Router();

// Rate limiting for transfer operations
const transferLimiter = require('express-rate-limit')({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 10, // limit each IP to 10 transfer requests per hour
    message: {
        error: 'تم تجاوز حد العمليات المسموح بها',
        retryAfter: '60 minutes'
    }
});

// Validation middleware
const validateTransfer = [
    body('amount')
        .isFloat({ min: 0.01, max: 999999999 })
        .withMessage('مبلغ التحويل غير صحيح'),
    body('currency')
        .isIn(['USD', 'EUR', 'GBP', 'SAR', 'AED', 'KWD', 'BHD', 'QAR', 'JOD', 'EGP', 'SYP', 'LBP', 'CAD', 'AUD', 'CHF', 'JPY', 'CNY', 'INR', 'BTC', 'ETH', 'USDT'])
        .withMessage('عملة غير مدعومة'),
    body('recipientEmail')
        .isEmail()
        .normalizeEmail()
        .withMessage('بريد المستلم غير صحيح'),
    body('recipientName')
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('اسم المستلم غير صحيح'),
    body('recipientBank')
        .trim()
        .isLength({ min: 2, max: 100 })
        .withMessage('اسم البنك مطلوب'),
    body('recipientAccountNumber')
        .matches(/^[a-zA-Z0-9\s\-_]+$/)
        .withMessage('رقم الحساب غير صحيح'),
    body('swiftCode')
        .matches(/^[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3})?$/)
        .withMessage('رمز SWIFT غير صحيح'),
    body('description')
        .optional()
        .trim()
        .isLength({ max: 140 })
        .withMessage('وصف التحويل طويل جداً')
];

// Helper functions
const calculateFee = (amount, type, currency) => {
    const feeRates = {
        'domestic': { rate: 0.005, min: 2, max: 50 }, // 0.5%, min $2, max $50
        'international': { rate: 0.015, min: 5, max: 200 }, // 1.5%, min $5, max $200
        'swift': { rate: 0.020, min: 10, max: 300 }, // 2.0%, min $10, max $300
        'sepa': { rate: 0.008, min: 1, max: 25 }, // 0.8%, min €1, max €25
        'ach': { rate: 0.003, min: 0.25, max: 15 }, // 0.3%, min $0.25, max $15
        'crypto': { rate: 0.010, min: 1, max: 100 }, // 1.0%, min $1, max $100
        'instant': { rate: 0.025, min: 0.50, max: 75 } // 2.5%, min $0.50, max $75
    };

    const rate = feeRates[type] || feeRates['international'];
    let fee = amount * rate.rate;
    
    // Convert min/max amounts based on currency
    const currencyMultipliers = {
        'USD': 1, 'EUR': 1, 'GBP': 1, 'CAD': 1, 'AUD': 1, 'CHF': 1,
        'SAR': 3.75, 'AED': 3.67, 'KWD': 0.30, 'BHD': 0.38, 'QAR': 3.64,
        'JOD': 0.71, 'EGP': 31.00, 'SYP': 2500, 'LBP': 1500,
        'JPY': 150, 'CNY': 7.2, 'INR': 83
    };
    
    const multiplier = currencyMultipliers[currency] || 1;
    fee = Math.max(fee, rate.min * multiplier);
    fee = Math.min(fee, rate.max * multiplier);
    
    return Math.round(fee * 100) / 100; // Round to 2 decimal places
};

const determineTransferType = (senderCurrency, receiverCurrency, senderCountry, receiverCountry) => {
    if (senderCurrency === receiverCurrency) {
        if (senderCountry === receiverCountry) {
            return 'domestic';
        } else {
            return 'international';
        }
    } else {
        if (['BTC', 'ETH', 'USDT'].includes(senderCurrency) || ['BTC', 'ETH', 'USDT'].includes(receiverCurrency)) {
            return 'crypto';
        } else if (['EUR'].includes(senderCurrency) && ['EUR'].includes(receiverCurrency)) {
            return 'sepa';
        } else if (['USD'].includes(senderCurrency) && ['USD'].includes(receiverCurrency)) {
            return 'ach';
        } else {
            return 'swift';
        }
    }
};

const exchangeRateAPI = async (from, to) => {
    try {
        if (from === to) return 1.0;
        
        // For demo purposes, return a mock exchange rate
        // In production, you would call a real API like:
        // const response = await axios.get(`https://api.exchangerate-api.com/v4/latest/${from}`);
        // return response.data.rates[to];
        
        const mockRates = {
            'USD-EUR': 0.85,
            'USD-GBP': 0.73,
            'USD-SAR': 3.75,
            'USD-AED': 3.67,
            'EUR-USD': 1.18,
            'GBP-USD': 1.37,
            'SAR-USD': 0.27,
            'AED-USD': 0.27
        };
        
        return mockRates[`${from}-${to}`] || 1.0;
    } catch (error) {
        return 1.0; // Fallback rate
    }
};

// =============================================
// Transfer Creation
// =============================================

/**
 * POST /api/transfers
 * Create new transfer
 */
router.post('/', transferLimiter, authenticateToken, validateTransfer, async (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: 'بيانات التحويل غير صحيحة',
                details: errors.array()
            });
        }

        const {
            amount,
            currency,
            recipientEmail,
            recipientName,
            recipientBank,
            recipientAccountNumber,
            swiftCode,
            description,
            purpose
        } = req.body;

        // Get sender account
        const senderAccount = await Account.findOne({
            userId: req.user.userId,
            currency: currency,
            status: 'active'
        });

        if (!senderAccount) {
            return res.status(400).json({
                error: 'لا يوجد حساب نشط بهذه العملة'
            });
        }

        // Check if recipient exists
        const recipientUser = await User.findOne({ email: recipientEmail });
        if (!recipientUser) {
            return res.status(404).json({
                error: 'المستلم غير موجود'
            });
        }

        // Get recipient account
        const recipientAccount = await Account.findOne({
            userId: recipientUser.userId,
            currency: currency,
            status: 'active'
        });

        // Determine transfer type and calculate fees
        const transferType = determineTransferType(
            currency,
            currency,
            'US', // sender country
            'US' // receiver country
        );
        
        const fee = calculateFee(amount, transferType, currency);
        const totalAmount = amount + fee;

        // Check balance
        if (senderAccount.availableBalance < totalAmount) {
            return res.status(400).json({
                error: 'رصيد غير كافي',
                availableBalance: senderAccount.availableBalance,
                requiredAmount: totalAmount
            });
        }

        // Check daily limits
        if (!senderAccount.checkDailyLimit(totalAmount, 'transfer')) {
            return res.status(400).json({
                error: 'تم تجاوز الحد اليومي للتحويلات',
                dailyLimit: senderAccount.dailyTransferLimit
            });
        }

        // Create transfer record
        const transfer = new Transfer({
            transactionId: Transfer.generateTransactionId(),
            referenceId: Transfer.generateReferenceId(),
            swiftReference: Transfer.generateSWIFTReference(),
            
            senderId: req.user.userId,
            senderAccountId: senderAccount.accountId,
            
            receiverId: recipientUser.userId,
            receiverAccountId: recipientAccount ? recipientAccount.accountId : null,
            
            transferType,
            amount,
            currency,
            originalAmount: amount,
            originalCurrency: currency,
            exchangeRate: 1.0,
            
            fee: {
                amount: fee,
                currency: currency,
                breakdown: [
                    {
                        type: 'processing',
                        amount: fee,
                        currency: currency,
                        description: 'رسوم معالجة التحويل'
                    }
                ]
            },
            totalAmount,
            
            recipientDetails: {
                name: recipientName,
                bankName: recipientBank,
                accountNumber: recipientAccountNumber,
                swiftCode: swiftCode,
                purpose: purpose || 'payment'
            },
            
            description: description,
            
            status: 'pending',
            requestedAt: new Date(),
            
            complianceChecks: {
                amlPassed: true,
                sanctionsPassed: true,
                riskScore: 0,
                flagged: false
            },
            
            authentication: {
                required: amount >= 1000, // Require 2FA for amounts >= $1000
                completed: amount < 1000,
                method: amount >= 1000 ? 'app' : null
            }
        });

        await transfer.save();

        // Update account balances
        await senderAccount.reserveAmount(totalAmount);

        // Emit real-time update if socket.io is available
        if (global.broadcastFunctions) {
            global.broadcastFunctions.transferUpdate(transfer.transactionId, {
                type: 'transfer_created',
                data: transfer.summary
            });
            
            global.broadcastFunctions.notification(req.user.userId, {
                type: 'transfer_created',
                title: 'تحويل جديد',
                message: `تم إنشاء تحويل بقيمة ${amount} ${currency}`,
                timestamp: new Date()
            });
        }

        res.status(201).json({
            success: true,
            message: 'تم إنشاء التحويل بنجاح',
            data: {
                transfer: transfer.summary,
                nextStep: transfer.authentication.required ? 'verification_required' : 'confirmation_required'
            }
        });

    } catch (error) {
        console.error('Create transfer error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء إنشاء التحويل'
        });
    }
});

// =============================================
// Transfer Verification (2FA)
// =============================================

/**
 * POST /api/transfers/:transactionId/verify
 * Verify transfer with 2FA code
 */
router.post('/:transactionId/verify', authenticateToken, [
    body('code').notEmpty().withMessage('رمز التحقق مطلوب')
], async (req, res) => {
    try {
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: 'رمز التحقق غير صحيح',
                details: errors.array()
            });
        }

        const { transactionId } = req.params;
        const { code } = req.body;

        const transfer = await Transfer.findOne({
            transactionId,
            senderId: req.user.userId
        });

        if (!transfer) {
            return res.status(404).json({
                error: 'العملية غير موجودة'
            });
        }

        if (transfer.status !== 'pending') {
            return res.status(400).json({
                error: 'العملية لا يمكن التحقق منها'
            });
        }

        if (!transfer.authentication.required) {
            return res.status(400).json({
                error: 'هذه العملية لا تتطلب مصادقة ثنائية'
            });
        }

        // In a real implementation, you would verify the 2FA code
        // For demo purposes, accept code "123456"
        if (code !== '123456') {
            transfer.authentication.attempts += 1;
            
            if (transfer.authentication.attempts >= 3) {
                await transfer.updateStatus('failed', 'Attempts exceeded', req.user.userId);
                
                // Release reserved amount
                const senderAccount = await Account.findOne({ accountId: transfer.senderAccountId });
                if (senderAccount) {
                    await senderAccount.releaseReservedAmount(transfer.totalAmount);
                }
                
                return res.status(400).json({
                    error: 'تم تجاوز عدد المحاولات المسموح بها'
                });
            }
            
            await transfer.save();
            
            return res.status(400).json({
                error: 'رمز التحقق غير صحيح',
                attemptsRemaining: 3 - transfer.authentication.attempts
            });
        }

        // Mark as verified
        transfer.authentication.completed = true;
        transfer.authentication.verifiedAt = new Date();
        transfer.status = 'authorized';
        transfer.statusHistory.push({
            status: 'authorized',
            timestamp: new Date(),
            notes: 'تم التحقق بنجاح',
            userId: req.user.userId
        });

        await transfer.save();

        // Emit real-time update
        if (global.broadcastFunctions) {
            global.broadcastFunctions.transferUpdate(transfer.transactionId, {
                type: 'transfer_verified',
                data: { status: 'authorized' }
            });
        }

        res.json({
            success: true,
            message: 'تم التحقق بنجاح',
            data: {
                status: transfer.status,
                nextStep: 'confirmation_required'
            }
        });

    } catch (error) {
        console.error('Verify transfer error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء التحقق من التحويل'
        });
    }
});

// =============================================
// Transfer Confirmation
// =============================================

/**
 * POST /api/transfers/:transactionId/confirm
 * Confirm and process transfer
 */
router.post('/:transactionId/confirm', authenticateToken, async (req, res) => {
    try {
        const { transactionId } = req.params;

        const transfer = await Transfer.findOne({
            transactionId,
            senderId: req.user.userId
        });

        if (!transfer) {
            return res.status(404).json({
                error: 'العملية غير موجودة'
            });
        }

        if (transfer.status !== 'authorized') {
            return res.status(400).json({
                error: 'العملية غير مؤهلة للمعالجة'
            });
        }

        // Update transfer status
        await transfer.updateStatus('processing', 'بدء معالجة التحويل', req.user.userId);

        // Process the transfer (simulate real processing)
        setTimeout(async () => {
            try {
                // Update sender account (deduct amount)
                const senderAccount = await Account.findOne({ accountId: transfer.senderAccountId });
                if (senderAccount) {
                    await senderAccount.releaseReservedAmount(transfer.totalAmount);
                    await senderAccount.updateBalance(transfer.totalAmount, 'debit');
                }

                // If recipient account exists, credit it
                if (transfer.receiverAccountId) {
                    const recipientAccount = await Account.findOne({ accountId: transfer.receiverAccountId });
                    if (recipientAccount) {
                        await recipientAccount.updateBalance(transfer.amount, 'credit');
                    }
                }

                // Complete the transfer
                await transfer.updateStatus('completed', 'تم إنجاز التحويل بنجاح', req.user.userId);

                // Add tracking entry
                await transfer.addTrackingEntry('TransferSwift System', 'completed', 'تم إنجاز التحويل');

                // Emit real-time updates
                if (global.broadcastFunctions) {
                    global.broadcastFunctions.transferUpdate(transfer.transactionId, {
                        type: 'transfer_completed',
                        data: { status: 'completed' }
                    });
                    
                    global.broadcastFunctions.balanceUpdate(transfer.senderId, {
                        accountId: transfer.senderAccountId,
                        newBalance: senderAccount ? senderAccount.balance : 0
                    });
                    
                    if (transfer.receiverId) {
                        global.broadcastFunctions.balanceUpdate(transfer.receiverId, {
                            accountId: transfer.receiverAccountId,
                            newBalance: recipientAccount ? recipientAccount.balance : 0
                        });
                        
                        global.broadcastFunctions.notification(transfer.receiverId, {
                            type: 'transfer_received',
                            title: 'تحويل مستلم',
                            message: `تم استلام تحويل بقيمة ${transfer.amount} ${transfer.currency}`,
                            timestamp: new Date()
                        });
                    }
                }

            } catch (error) {
                console.error('Transfer processing error:', error);
                transfer.updateStatus('failed', error.message, null);
            }
        }, 2000); // Simulate processing delay

        res.json({
            success: true,
            message: 'تم إرسال التحويل للمعالجة',
            data: {
                transactionId: transfer.transactionId,
                status: transfer.status,
                estimatedTime: '2-5 دقائق'
            }
        });

    } catch (error) {
        console.error('Confirm transfer error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء تأكيد التحويل'
        });
    }
});

// =============================================
// Transfer Status
// =============================================

/**
 * GET /api/transfers/:transactionId/status
 * Get transfer status
 */
router.get('/:transactionId/status', authenticateToken, async (req, res) => {
    try {
        const { transactionId } = req.params;

        const transfer = await Transfer.findOne({
            transactionId,
            $or: [
                { senderId: req.user.userId },
                { receiverId: req.user.userId }
            ]
        }).populate('senderAccountId receiverAccountId');

        if (!transfer) {
            return res.status(404).json({
                error: 'العملية غير موجودة'
            });
        }

        res.json({
            success: true,
            data: {
                transfer: transfer.summary,
                tracking: transfer.tracking,
                statusHistory: transfer.statusHistory
            }
        });

    } catch (error) {
        console.error('Get transfer status error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء جلب حالة التحويل'
        });
    }
});

// =============================================
// Transfer History
// =============================================

/**
 * GET /api/transfers
 * Get user's transfer history
 */
router.get('/', authenticateToken, async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 20;
        const status = req.query.status;
        const type = req.query.type;
        const skip = (page - 1) * limit;

        // Build query
        const query = {
            $or: [
                { senderId: req.user.userId },
                { receiverId: req.user.userId }
            ]
        };

        if (status) query.status = status;
        if (type) query.transferType = type;

        const transfers = await Transfer.find(query)
            .sort({ requestedAt: -1 })
            .skip(skip)
            .limit(limit)
            .populate('senderAccountId', 'accountNumber bankName currency')
            .populate('receiverAccountId', 'accountNumber bankName currency');

        const total = await Transfer.countDocuments(query);

        res.json({
            success: true,
            data: {
                transfers: transfers.map(t => t.summary),
                pagination: {
                    current: page,
                    total: Math.ceil(total / limit),
                    count: transfers.length,
                    totalRecords: total
                }
            }
        });

    } catch (error) {
        console.error('Get transfer history error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء جلب سجل التحويلات'
        });
    }
});

// =============================================
// Cancel Transfer
// =============================================

/**
 * POST /api/transfers/:transactionId/cancel
 * Cancel pending transfer
 */
router.post('/:transactionId/cancel', authenticateToken, async (req, res) => {
    try {
        const { transactionId } = req.params;

        const transfer = await Transfer.findOne({
            transactionId,
            senderId: req.user.userId
        });

        if (!transfer) {
            return res.status(404).json({
                error: 'العملية غير موجودة'
            });
        }

        if (!['pending', 'authorized'].includes(transfer.status)) {
            return res.status(400).json({
                error: 'لا يمكن إلغاء هذه العملية'
            });
        }

        // Update transfer status
        await transfer.updateStatus('cancelled', 'تم الإلغاء من قبل المستخدم', req.user.userId);

        // Release reserved amount
        const senderAccount = await Account.findOne({ accountId: transfer.senderAccountId });
        if (senderAccount) {
            await senderAccount.releaseReservedAmount(transfer.totalAmount);
        }

        // Emit real-time update
        if (global.broadcastFunctions) {
            global.broadcastFunctions.transferUpdate(transfer.transactionId, {
                type: 'transfer_cancelled',
                data: { status: 'cancelled' }
            });
        }

        res.json({
            success: true,
            message: 'تم إلغاء التحويل بنجاح'
        });

    } catch (error) {
        console.error('Cancel transfer error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء إلغاء التحويل'
        });
    }
});

module.exports = router;