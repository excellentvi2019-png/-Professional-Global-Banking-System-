const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const rateLimit = require('express-rate-limit');
const User = require('../models/User');
const { body, validationResult } = require('express-validator');
const router = express.Router();

// Rate limiting for auth routes
const authLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 5, // limit each IP to 5 requests per windowMs
    message: {
        error: 'تم تجاوز حد المحاولات، يرجى المحاولة لاحقاً',
        retryAfter: '15 minutes'
    },
    standardHeaders: true,
    legacyHeaders: false,
});

// Validation middleware
const validateRegistration = [
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('بريد إلكتروني غير صحيح'),
    body('password')
        .isLength({ min: 8 })
        .withMessage('كلمة المرور يجب أن تكون 8 أحرف على الأقل')
        .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]/)
        .withMessage('كلمة المرور يجب أن تحتوي على حرف كبير وصغير ورقم ورمز خاص'),
    body('firstName')
        .trim()
        .isLength({ min: 2, max: 50 })
        .withMessage('الاسم الأول يجب أن يكون بين 2-50 حرف'),
    body('lastName')
        .trim()
        .isLength({ min: 2, max: 50 })
        .withMessage('اسم العائلة يجب أن يكون بين 2-50 حرف'),
    body('phone')
        .matches(/^\+?[1-9]\d{1,14}$/)
        .withMessage('رقم هاتف غير صحيح'),
    body('dateOfBirth')
        .isISO8601()
        .toDate()
        .withMessage('تاريخ غير صحيح'),
    body('nationality')
        .notEmpty()
        .withMessage('الجنسية مطلوبة')
];

const validateLogin = [
    body('email')
        .isEmail()
        .normalizeEmail()
        .withMessage('بريد إلكتروني غير صحيح'),
    body('password')
        .notEmpty()
        .withMessage('كلمة المرور مطلوبة')
];

// Helper functions
const generateToken = (user) => {
    return jwt.sign(
        { 
            userId: user.userId,
            email: user.email,
            role: user.accountTier
        },
        process.env.JWT_SECRET || 'transswift-jwt-secret-2025',
        { expiresIn: '24h' }
    );
};

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({
            error: 'رمز الوصول مطلوب'
        });
    }

    jwt.verify(token, process.env.JWT_SECRET || 'transswift-jwt-secret-2025', (err, user) => {
        if (err) {
            return res.status(403).json({
                error: 'رمز الوصول غير صالح'
            });
        }
        req.user = user;
        next();
    });
};

const optionalAuth = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (token) {
        jwt.verify(token, process.env.JWT_SECRET || 'transswift-jwt-secret-2025', (err, user) => {
            if (!err) {
                req.user = user;
            }
        });
    }
    next();
};

// =============================================
// Registration Routes
// =============================================

/**
 * POST /api/auth/register
 * Register new user
 */
router.post('/register', authLimiter, validateRegistration, async (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: 'بيانات غير صحيحة',
                details: errors.array()
            });
        }

        const {
            email,
            password,
            firstName,
            lastName,
            phone,
            dateOfBirth,
            nationality,
            address
        } = req.body;

        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(409).json({
                error: 'البريد الإلكتروني مستخدم مسبقاً'
            });
        }

        // Validate age (must be 18+)
        const age = new Date().getFullYear() - new Date(dateOfBirth).getFullYear();
        if (age < 18) {
            return res.status(400).json({
                error: 'يجب أن يكون العمر 18 سنة على الأقل'
            });
        }

        // Create new user
        const userId = User.generateUserId();
        const user = new User({
            userId,
            email,
            password,
            firstName,
            lastName,
            phone,
            dateOfBirth,
            nationality,
            address,
            status: 'inactive', // Requires KYC verification
            kycStatus: 'pending'
        });

        await user.save();

        // Generate token
        const token = generateToken(user);

        // Add session token
        await user.addSessionToken(token, req.ip, req.get('User-Agent'));

        res.status(201).json({
            success: true,
            message: 'تم إنشاء الحساب بنجاح',
            data: {
                userId: user.userId,
                email: user.email,
                name: user.fullName,
                kycStatus: user.kycStatus,
                status: user.status
            },
            token
        });

    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء إنشاء الحساب'
        });
    }
});

// =============================================
// Login Routes
// =============================================

/**
 * POST /api/auth/login
 * User login
 */
router.post('/login', authLimiter, validateLogin, async (req, res) => {
    try {
        // Check validation errors
        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            return res.status(400).json({
                error: 'بيانات تسجيل الدخول غير صحيحة',
                details: errors.array()
            });
        }

        const { email, password } = req.body;

        // Find user
        const user = await User.findOne({ email });
        if (!user) {
            await User.findOneAndUpdate(
                { email }, 
                { $inc: { failedLoginAttempts: 1 } },
                { new: false }
            );
            
            return res.status(401).json({
                error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
            });
        }

        // Check if account is suspended
        if (user.status === 'suspended') {
            return res.status(403).json({
                error: 'الحساب محظور مؤقتاً'
            });
        }

        // Check if account is closed
        if (user.status === 'closed') {
            return res.status(403).json({
                error: 'الحساب مغلق'
            });
        }

        // Verify password
        const isPasswordValid = await user.comparePassword(password);
        if (!isPasswordValid) {
            await user.incrementFailedAttempts();
            
            return res.status(401).json({
                error: 'البريد الإلكتروني أو كلمة المرور غير صحيحة'
            });
        }

        // Reset failed attempts on successful login
        await user.resetFailedAttempts();

        // Generate token
        const token = generateToken(user);

        // Add session token
        await user.addSessionToken(token, req.ip, req.get('User-Agent'));

        res.json({
            success: true,
            message: 'تم تسجيل الدخول بنجاح',
            data: {
                userId: user.userId,
                email: user.email,
                name: user.fullName,
                kycStatus: user.kycStatus,
                accountTier: user.accountTier,
                status: user.status,
                lastLoginAt: user.lastLoginAt
            },
            token
        });

    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء تسجيل الدخول'
        });
    }
});

// =============================================
// Authentication Verification
// =============================================

/**
 * GET /api/auth/verify
 * Verify token and return user info
 */
router.get('/verify', authenticateToken, async (req, res) => {
    try {
        const user = await User.findOne({ userId: req.user.userId });
        if (!user) {
            return res.status(404).json({
                error: 'المستخدم غير موجود'
            });
        }

        res.json({
            success: true,
            data: {
                userId: user.userId,
                email: user.email,
                name: user.fullName,
                kycStatus: user.kycStatus,
                accountTier: user.accountTier,
                status: user.status,
                twoFactorEnabled: user.twoFactorEnabled
            }
        });

    } catch (error) {
        console.error('Verify token error:', error);
        res.status(500).json({
            error: 'خطأ في التحقق من التوكن'
        });
    }
});

// =============================================
// Password Management
// =============================================

/**
 * POST /api/auth/forgot-password
 * Request password reset
 */
router.post('/forgot-password', authLimiter, [
    body('email').isEmail().normalizeEmail().withMessage('بريد إلكتروني غير صحيح')
], async (req, res) => {
    try {
        const { email } = req.body;

        const user = await User.findOne({ email });
        if (!user) {
            // Don't reveal if email exists or not
            return res.json({
                success: true,
                message: 'إذا كان البريد الإلكتروني مسجلاً، ستتلقى تعليمات إعادة تعيين كلمة المرور'
            });
        }

        // In a real implementation, you would:
        // 1. Generate a reset token
        // 2. Store it in database with expiration
        // 3. Send email with reset link
        // For now, we'll just return success

        res.json({
            success: true,
            message: 'تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك الإلكتروني'
        });

    } catch (error) {
        console.error('Forgot password error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء معالجة طلب إعادة تعيين كلمة المرور'
        });
    }
});

// =============================================
// Logout
// =============================================

/**
 * POST /api/auth/logout
 * User logout
 */
router.post('/logout', authenticateToken, async (req, res) => {
    try {
        const user = await User.findOne({ userId: req.user.userId });
        if (user) {
            // Remove current session token
            const authHeader = req.headers['authorization'];
            const token = authHeader && authHeader.split(' ')[1];
            await user.removeSessionToken(token);
        }

        res.json({
            success: true,
            message: 'تم تسجيل الخروج بنجاح'
        });

    } catch (error) {
        console.error('Logout error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء تسجيل الخروج'
        });
    }
});

// =============================================
// Two-Factor Authentication
// =============================================

/**
 * POST /api/auth/enable-2fa
 * Enable two-factor authentication
 */
router.post('/enable-2fa', authenticateToken, async (req, res) => {
    try {
        const user = await User.findOne({ userId: req.user.userId });
        if (!user) {
            return res.status(404).json({
                error: 'المستخدم غير موجود'
            });
        }

        // In a real implementation, you would:
        // 1. Generate a secret key
        // 2. Generate QR code
        // 3. Return both to user for setup
        const secret = 'DEMO_SECRET_KEY_' + Date.now();

        user.twoFactorEnabled = true;
        user.twoFactorSecret = secret;
        await user.save();

        res.json({
            success: true,
            message: 'تم تفعيل المصادقة الثنائية',
            data: {
                secret: secret,
                qrCode: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=='
            }
        });

    } catch (error) {
        console.error('Enable 2FA error:', error);
        res.status(500).json({
            error: 'حدث خطأ أثناء تفعيل المصادقة الثنائية'
        });
    }
});

// Export middleware for use in other routes
router.authenticateToken = authenticateToken;
router.optionalAuth = optionalAuth;

module.exports = router;